"""楽天レビュー分析 Streamlit アプリ.

起動方法 (どちらでもOK):
  - Desktop の「楽天レビュー分析.app」をダブルクリック
  - CLI: cd ~/rakuten_analysis && ./venv/bin/streamlit run app.py
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

import fetch_reviews as fr
import analyze_reviews as ar

st.set_page_config(
    page_title="楽天レビュー分析",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ─────────────────────────────────────────────────────────────
# Sidebar
# ─────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("詳細設定")
    max_pages = st.number_input(
        "取得する最大ページ数 (1ページ=30件)",
        min_value=1, max_value=999, value=10, step=1,
        help="動作確認は5〜10ページ程度推奨。全件は時間がかかります。",
    )
    max_reviews = st.number_input(
        "Claude分析の対象上限件数",
        min_value=10, max_value=2000, value=200, step=10,
        help="多すぎるとClaudeコストが嵩みます。",
    )
    model = st.selectbox(
        "使用モデル",
        ["claude-sonnet-4-6", "claude-opus-4-7", "claude-haiku-4-5-20251001"],
        index=0,
        help="精度はOpus > Sonnet > Haiku、コストは逆順。",
    )
    st.divider()
    st.caption("数値ID直接指定 (URLが解決できない時)")
    direct_shop_id = st.text_input("shop_id", value="")
    direct_item_id = st.text_input("item_id", value="")

# ─────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────
st.title("楽天レビュー分析ツール")
st.caption("商品URLを貼り付けて「実行」を押すだけ。レビュー取得 → Claudeで分析 → 4種類のCSVが出ます。")

url = st.text_input(
    "楽天商品URL",
    placeholder="https://item.rakuten.co.jp/＜店舗ID＞/＜商品ID＞/",
)
run = st.button("レビュー取得 → 分析実行", type="primary", use_container_width=True)


# ─────────────────────────────────────────────────────────────
# Run pipeline
# ─────────────────────────────────────────────────────────────
def _make_progress(status_box, progress_bar):
    """fetch/analyze に渡す進捗コールバックを作る."""
    def cb(msg: str, current=None, total=None) -> None:
        status_box.write(msg)
        if current is not None and total:
            progress_bar.progress(min(current / total, 1.0))
    return cb


if run:
    if not url and not (direct_shop_id and direct_item_id):
        st.error("商品URL、または shop_id + item_id の両方を入力してください。")
        st.stop()

    # --- 取得 ---
    fetch_status = st.status("レビューを取得中...", expanded=True)
    fetch_bar = fetch_status.progress(0.0)
    fetch_cb = _make_progress(fetch_status, fetch_bar)

    try:
        reviews, info = fr.fetch_all(
            url or None,
            max_pages=int(max_pages),
            shop_id=direct_shop_id or None,
            item_id=direct_item_id or None,
            progress=fetch_cb,
        )
    except SystemExit as e:
        fetch_status.update(label=f"取得失敗: {e}", state="error")
        st.stop()
    except Exception as e:  # noqa: BLE001
        fetch_status.update(label=f"取得失敗: {e}", state="error")
        st.exception(e)
        st.stop()

    if not reviews:
        fetch_status.update(label="レビュー0件のため終了", state="error")
        st.stop()

    out_dir = fr.make_output_dir(info["shop_code"], info["item_code"])
    csv_path = out_dir / "reviews_raw.csv"
    fr.write_reviews_csv(reviews, csv_path)
    # メタ情報も書き出し
    from datetime import datetime
    meta_path = out_dir / "fetch_meta.txt"
    with open(meta_path, "w", encoding="utf-8") as f:
        for k, v in info.items():
            f.write(f"{k}: {v}\n")
        f.write(f"fetched_at: {datetime.now().isoformat(timespec='seconds')}\n")

    fetch_bar.progress(1.0)
    fetch_status.update(
        label=f"取得完了: {len(reviews)}件 (保存先: {out_dir.name})",
        state="complete",
    )

    # --- 分析 ---
    analyze_status = st.status("Claudeで分析中... (1バッチあたり30秒〜1分)", expanded=True)
    analyze_bar = analyze_status.progress(0.0)
    analyze_cb = _make_progress(analyze_status, analyze_bar)

    try:
        result = ar.analyze_csv(
            csv_path, model=model,
            max_reviews=int(max_reviews), progress=analyze_cb,
        )
    except SystemExit as e:
        analyze_status.update(label=f"分析失敗: {e}", state="error")
        st.stop()
    except Exception as e:  # noqa: BLE001
        analyze_status.update(label=f"分析失敗: {e}", state="error")
        st.exception(e)
        st.stop()

    analyze_bar.progress(1.0)
    analyze_status.update(label="分析完了", state="complete")

    # 結果を session_state に保存
    st.session_state["out_dir"] = str(out_dir)
    st.session_state["fetched_count"] = len(reviews)
    st.session_state["total_count"] = info.get("total_count")


# ─────────────────────────────────────────────────────────────
# Display results
# ─────────────────────────────────────────────────────────────
def _read_csv(path: Path) -> pd.DataFrame:
    if path.exists():
        return pd.read_csv(path, encoding="utf-8-sig")
    return pd.DataFrame()


def _download(df: pd.DataFrame, label: str, filename: str, key: str) -> None:
    if df.empty:
        return
    csv_bytes = df.to_csv(index=False).encode("utf-8-sig")
    st.download_button(
        label=label, data=csv_bytes, file_name=filename,
        mime="text/csv", key=key, use_container_width=True,
    )


if "out_dir" in st.session_state:
    out_dir = Path(st.session_state["out_dir"])
    st.divider()
    st.subheader(f"結果: {out_dir.name}")
    st.caption(f"出力先フォルダ: `{out_dir}`")

    summary_df = _read_csv(out_dir / "summary.csv")
    neg_df = _read_csv(out_dir / "analysis_negative.csv")
    pos_df = _read_csv(out_dir / "analysis_positive.csv")
    words_df = _read_csv(out_dir / "analysis_words.csv")
    raw_df = _read_csv(out_dir / "reviews_raw.csv")

    tab_summary, tab_neg, tab_pos, tab_words, tab_raw = st.tabs([
        "サマリー", "ネガTOP", "ポジTOP", "自然発生ワード", "全レビュー(生)",
    ])

    with tab_summary:
        if not summary_df.empty:
            kv = dict(zip(summary_df["metric"], summary_df["value"]))
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("総レビュー件数", kv.get("総レビュー件数", "-"))
            c2.metric("平均評価点", kv.get("平均評価点", "-"))
            c3.metric("ポジ判定 (★4-5)", kv.get("ポジティブ判定件数(★4-5)", "-"))
            c4.metric("ネガ判定 (★1-2)", kv.get("ネガティブ判定件数(★1-2)", "-"))

            st.markdown("##### ★分布")
            star_rows = []
            for n in [5, 4, 3, 2, 1]:
                star_rows.append({"star": f"★{n}", "count": int(kv.get(f"★{n}件数", 0))})
            star_df = pd.DataFrame(star_rows).set_index("star")
            st.bar_chart(star_df, horizontal=True, height=240)

            with st.expander("全メトリクスを表示"):
                st.dataframe(summary_df, use_container_width=True, hide_index=True)
            _download(summary_df, "summary.csv をダウンロード", "summary.csv", "dl_summary")

    with tab_neg:
        if neg_df.empty:
            st.info("ネガティブ候補は抽出されませんでした。")
        else:
            st.caption("severity・category・rating 列のヘッダクリックでソートできます。")
            st.dataframe(neg_df, use_container_width=True, hide_index=True)
            _download(neg_df, "analysis_negative.csv をダウンロード", "analysis_negative.csv", "dl_neg")

    with tab_pos:
        if pos_df.empty:
            st.info("ポジティブ候補は抽出されませんでした。")
        else:
            st.caption("intensity・category・rating 列のヘッダクリックでソートできます。")
            st.dataframe(pos_df, use_container_width=True, hide_index=True)
            _download(pos_df, "analysis_positive.csv をダウンロード", "analysis_positive.csv", "dl_pos")

    with tab_words:
        if words_df.empty:
            st.info("自然発生ワードは抽出されませんでした。")
        else:
            c1, c2 = st.columns([1, 5])
            type_filter = c1.radio("種別", ["すべて", "word", "phrase"], horizontal=False)
            view = words_df if type_filter == "すべて" else words_df[words_df["type"] == type_filter]
            c2.metric("該当件数", len(view))
            st.dataframe(view, use_container_width=True, hide_index=True)
            _download(words_df, "analysis_words.csv をダウンロード", "analysis_words.csv", "dl_words")

    with tab_raw:
        if raw_df.empty:
            st.info("レビューデータがありません。")
        else:
            star_filter = st.multiselect(
                "★で絞り込み", [5, 4, 3, 2, 1], default=[5, 4, 3, 2, 1]
            )
            view = raw_df[raw_df["rating"].isin(star_filter)]
            st.caption(f"{len(view)} / {len(raw_df)} 件")
            st.dataframe(view, use_container_width=True, hide_index=True, height=500)
            _download(raw_df, "reviews_raw.csv をダウンロード", "reviews_raw.csv", "dl_raw")
