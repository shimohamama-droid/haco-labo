"""楽天商品レビュー全件取得スクリプト.

使い方:
    python fetch_reviews.py https://item.rakuten.co.jp/<shop>/<item>/
    python fetch_reviews.py https://item.rakuten.co.jp/<shop>/<item>/ --analyze
    python fetch_reviews.py https://item.rakuten.co.jp/<shop>/<item>/ --max-pages 50

仕組み:
    1. 商品ページから内部shop_id/item_id(数値)を抽出
    2. レビューページ(https://review.rakuten.co.jp/item/1/{shop_id}_{item_id}/{page}.1/)を巡回
    3. BeautifulSoupでレビューを抽出してCSV出力
"""

from __future__ import annotations

import argparse
import csv
import math
import os
import random
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import requests
from bs4 import BeautifulSoup, Tag

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
)
HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "ja,en-US;q=0.9,en;q=0.8",
}
REVIEWS_PER_PAGE = 30  # 楽天レビューページは1ページ30件固定
SLEEP_BASE = 1.5  # 各リクエスト間のスリープ秒数(基準)
SLEEP_JITTER = 0.6  # ランダムジッタ
TIMEOUT = 20


def parse_item_url(url: str) -> tuple[str, str]:
    """item.rakuten.co.jp のURLから shop_code と item_code を抽出."""
    m = re.search(r"item\.rakuten\.co\.jp/([A-Za-z0-9_\-]+)/([A-Za-z0-9_\-\.]+)/?", url)
    if not m:
        raise ValueError(f"楽天商品URLとして解釈できません: {url}")
    return m.group(1), m.group(2)


def _extract_ids_from_html(html: str) -> tuple[Optional[str], Optional[str], list[str]]:
    """HTMLから shop_id と item_id を複数パターンで抽出する.

    戻り値: (shop_id, item_id, 試したパターン名のログ)
    """
    tried: list[str] = []

    # パターン1: 新型レビューページへの直接リンク
    # 例: <a href="https://review.rakuten.co.jp/item/1/342933_10000003/...">
    name = "review.rakuten.co.jp/item/1/<shop>_<item>"
    m = re.search(r"review\.rakuten\.co\.jp/item/1/(\d+)_(\d+)", html)
    tried.append(f"{name} → {'HIT' if m else 'miss'}")
    if m:
        return m.group(1), m.group(2), tried

    # パターン2: data-item-to-compare-data 等の埋め込みJSON
    # 例: &quot;itemId&quot;: 12345678, &quot;shopId&quot;: 123456
    name = 'JSON "itemId"+"shopId"'
    item_m = re.search(r'(?:&quot;|")itemId(?:&quot;|")\s*:\s*"?(\d+)"?', html)
    shop_m = re.search(r'(?:&quot;|")shopId(?:&quot;|")\s*:\s*"?(\d+)"?', html)
    tried.append(f"{name} → item={'HIT' if item_m else 'miss'}, shop={'HIT' if shop_m else 'miss'}")
    if item_m and shop_m:
        return shop_m.group(1), item_m.group(1), tried

    # パターン3: クエリ文字列スタイル shop_id=... & item_id=...
    name = "URL query shop_id=&item_id="
    sid_m = re.search(r"[?&]shop_?id=(\d+)", html, flags=re.IGNORECASE)
    iid_m = re.search(r"[?&]item_?id=(\d+)", html, flags=re.IGNORECASE)
    tried.append(f"{name} → shop={'HIT' if sid_m else 'miss'}, item={'HIT' if iid_m else 'miss'}")
    if sid_m and iid_m:
        return sid_m.group(1), iid_m.group(1), tried

    # パターン4: 短縮形 sid=... & iid=... (古い楽天ページ系)
    name = "URL query sid=&iid="
    sid2 = re.search(r"[?&]sid=(\d+)", html)
    iid2 = re.search(r"[?&]iid=(\d+)", html)
    tried.append(f"{name} → sid={'HIT' if sid2 else 'miss'}, iid={'HIT' if iid2 else 'miss'}")
    if sid2 and iid2:
        return sid2.group(1), iid2.group(1), tried

    # パターン5: shopid="..." 属性 + item要素
    name = 'attribute shopid=".." + itemId'
    shop3 = re.search(r'shopid\s*=\s*"(\d+)"', html, flags=re.IGNORECASE)
    item3 = re.search(r'(?:itemId|item_id)\s*[:=]\s*"?(\d+)"?', html)
    tried.append(f"{name} → shop={'HIT' if shop3 else 'miss'}, item={'HIT' if item3 else 'miss'}")
    if shop3 and item3:
        return shop3.group(1), item3.group(1), tried

    # パターン6: shop_bid=... (カートリンク) + 任意のitem識別
    name = "shop_bid (cart link)"
    sbid = re.search(r"shop_bid=(\d+)", html)
    tried.append(f"{name} → shop_bid={'HIT' if sbid else 'miss'}")
    if sbid:
        # この場合は item_id だけ別途探す
        item4 = re.search(r"(?:itemId|item_id|iid)\s*[:=]\s*\"?(\d+)\"?", html)
        if item4:
            return sbid.group(1), item4.group(1), tried

    return None, None, tried


def resolve_numeric_ids(item_url: str, session: requests.Session) -> tuple[str, str]:
    """商品ページにアクセスし、レビューURLに使う数値ID(shop_id, item_id)を返す."""
    r = session.get(item_url, headers=HEADERS, timeout=TIMEOUT)
    if r.status_code == 404:
        raise SystemExit("商品が見つかりません(404)")
    if r.status_code >= 400:
        raise SystemExit(f"商品ページの取得に失敗しました (HTTP {r.status_code})")
    # 楽天は商品ページごとにエンコーディングが違う(新: UTF-8 / 旧: EUC-JP)
    # requests が apparent_encoding を見落とすことがあるため明示的にデコード
    if r.encoding and r.encoding.lower() == "iso-8859-1":
        r.encoding = r.apparent_encoding
    html = r.text

    shop_id, item_id, tried = _extract_ids_from_html(html)
    if shop_id and item_id:
        return shop_id, item_id

    print("商品ページからレビュー用の内部IDを取得できませんでした。", file=sys.stderr)
    print("試したパターン:", file=sys.stderr)
    for line in tried:
        print(f"  - {line}", file=sys.stderr)
    print(
        "\n回避策: --shop-id <数字> --item-id <数字> を直接指定して再実行してください。",
        file=sys.stderr,
    )
    raise SystemExit(2)


def fetch_review_page(
    shop_id: str, item_id: str, page: int, session: requests.Session
) -> Optional[BeautifulSoup]:
    """1ページぶんのレビューHTMLを取得しBeautifulSoupで返す."""
    url = f"https://review.rakuten.co.jp/item/1/{shop_id}_{item_id}/{page}.1/"
    r = session.get(url, headers=HEADERS, timeout=TIMEOUT)
    if r.status_code == 404:
        return None
    if r.status_code >= 400:
        print(f"  [warn] page {page}: HTTP {r.status_code}", file=sys.stderr)
        return None
    return BeautifulSoup(r.text, "lxml")


def extract_total_count(soup: BeautifulSoup) -> Optional[int]:
    """1ページ目のmeta/title類から総レビュー件数を抽出."""
    text_blob = str(soup)
    # 例: "のレビュー情報。10289件"
    m = re.search(r"のレビュー情報。(\d+(?:,\d+)*)\s*件", text_blob)
    if m:
        return int(m.group(1).replace(",", ""))
    # フォールバック: 最初に出てくる "N件" を採用
    m = re.search(r"(\d+(?:,\d+)*)\s*件", text_blob)
    if m:
        return int(m.group(1).replace(",", ""))
    return None


def _first_class_match(elem: Tag, substr: str) -> Optional[Tag]:
    return elem.select_one(f'[class*="{substr}"]')


def extract_reviews(soup: BeautifulSoup) -> list[dict]:
    """1ページぶんのレビュー(<li>)をdictのリストにして返す."""
    # ユーザーレビューは .review-body--XXX を含む li
    bodies = soup.select('[class*="review-body--"]')
    reviews: list[dict] = []
    seen_li = set()
    for body in bodies:
        # 直近のli祖先を遡る
        li = body.find_parent("li")
        if li is None or id(li) in seen_li:
            continue
        seen_li.add(id(li))

        # ショップコメント(返信)の場合スキップ
        if li.select_one('[class*="shop-comment"]'):
            # ショップコメントもbodyを含むことがある — 同じliに別のreview-bodyが見つかる場合は除外
            # ただしユーザーレビュー直下にあるショップコメントは混在ありうるので、
            # body自身がshop-commentの子孫ならそのreviewを丸ごと捨てるのではなく、
            # ユーザー本文の方だけを取りたい。以下で再検査する。
            user_body = None
            for b in li.select('[class*="review-body--"]'):
                if not b.find_parent(class_=re.compile(r"shop-comment")):
                    user_body = b
                    break
            if user_body is None:
                continue
            body = user_body

        # 評価
        rating = _extract_rating(li)
        # 日付
        posted_date = _extract_date(li)
        # ニックネーム
        nickname = _extract_text(li, "reviewer-name--")
        # バリエーション
        variation = _extract_variation(li)
        # 本文(改行保持)
        body_text = body.get_text("\n", strip=True)

        reviews.append(
            {
                "rating": rating,
                "posted_date": posted_date,
                "nickname": nickname,
                "variation": variation,
                "body": body_text,
                "char_count": len(body_text),
            }
        )
    return reviews


def _extract_rating(li: Tag) -> Optional[int]:
    rating_block = _first_class_match(li, "rating--")
    if not rating_block:
        return None
    # 数値テキスト(1〜5)を含むspanを探す
    for span in rating_block.select('[class*="text-container--"]'):
        t = span.get_text(strip=True)
        if t.isdigit() and 1 <= int(t) <= 5:
            return int(t)
    # フォールバック: 塗りつぶしstar画像の枚数を数える
    stars = rating_block.select('img[alt="star-rating"]')
    filled = sum(1 for s in stars if "star-empty" not in (s.get("src") or ""))
    return filled if filled else None


def _extract_date(li: Tag) -> Optional[str]:
    """日付らしきテキスト(YYYY/MM/DD)を探してYYYY-MM-DD形式で返す."""
    for div in li.find_all("div"):
        t = div.get_text(strip=True)
        m = re.match(r"^(\d{4})/(\d{1,2})/(\d{1,2})$", t)
        if m:
            y, mth, d = m.groups()
            return f"{y}-{int(mth):02d}-{int(d):02d}"
    return None


def _extract_text(li: Tag, class_substr: str) -> str:
    el = _first_class_match(li, class_substr)
    return el.get_text(strip=True) if el else ""


def _extract_variation(li: Tag) -> str:
    """バリエーション(色/サイズ等)テキストを抽出. 存在しなければ空文字."""
    # バリエーション行は本文の上にあり、<span>で `本体カラー:xxx | サイズ:yyy` のような書式
    # 構造的特定は難しいので、`:` を含み、かつ本文・ニックネーム・タイトル相当でないテキストを拾う
    for span in li.find_all("span"):
        t = span.get_text(" ", strip=True)
        if ":" in t and "|" in t and len(t) < 200:
            return t
    # | が無くても `xxx:yyy` 形式は変動表記の可能性
    for span in li.find_all("span"):
        t = span.get_text(" ", strip=True)
        if re.match(r"^[^\s:]{1,30}:[^\s].{0,100}$", t):
            return t
    return ""


def _safe_dirname(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_\-]", "_", s)


def make_output_dir(shop_code: str, item_code: str) -> Path:
    # スクリプト本体の隣に review_outputs/ を作る
    # (Desktop配下を避けることで .app からのTCC制限も回避)
    base = Path(__file__).resolve().parent / "review_outputs"
    base.mkdir(parents=True, exist_ok=True)
    today = datetime.now().strftime("%Y-%m-%d")
    name = f"{today}_{_safe_dirname(shop_code)}_{_safe_dirname(item_code)}"
    out = base / name
    if out.exists():
        i = 2
        while (base / f"{name}_{i}").exists():
            i += 1
        out = base / f"{name}_{i}"
    out.mkdir(parents=True)
    return out


def write_reviews_csv(reviews: list[dict], path: Path) -> None:
    fields = ["review_id", "rating", "posted_date", "nickname", "variation", "body", "char_count"]
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for i, r in enumerate(reviews, 1):
            w.writerow({"review_id": f"r{i:05d}", **r})


def fetch_all(
    item_url: Optional[str],
    max_pages: Optional[int] = None,
    shop_id: Optional[str] = None,
    item_id: Optional[str] = None,
    progress=None,
) -> tuple[list[dict], dict]:
    """レビュー全件取得のエントリポイント.

    progress: callable(message: str, current: int|None, total: int|None) -> None
              StreamlitなどのUIから進捗を受け取りたい時に渡す。
    """
    def emit(msg: str, current: Optional[int] = None, total: Optional[int] = None) -> None:
        if progress:
            progress(msg, current, total)
        else:
            print(msg)

    session = requests.Session()
    if item_url:
        shop_code, item_code = parse_item_url(item_url)
        emit(f"商品: {shop_code}/{item_code}")
    else:
        shop_code = f"shop{shop_id}" if shop_id else "_"
        item_code = f"item{item_id}" if item_id else "_"
        emit("商品URL未指定: 直接指定された数値IDのみで実行します。")
    if not (shop_id and item_id):
        if not item_url:
            raise SystemExit("--shop-id と --item-id を両方指定するか、商品URLを渡してください。")
        shop_id, item_id = resolve_numeric_ids(item_url, session)
    emit(f"内部ID: {shop_id}_{item_id}")

    soup = fetch_review_page(shop_id, item_id, 1, session)
    if soup is None:
        raise SystemExit("レビューページにアクセスできませんでした")

    total_count = extract_total_count(soup)
    if total_count is None:
        emit("総レビュー件数の取得に失敗。空ページに当たるまで巡回します。")
        total_pages = max_pages or 999
    else:
        total_pages = math.ceil(total_count / REVIEWS_PER_PAGE)
        emit(f"総レビュー件数: {total_count} (推定 {total_pages} ページ)")

    if max_pages is not None:
        total_pages = min(total_pages, max_pages)

    if total_count == 0:
        return [], {"shop_code": shop_code, "item_code": item_code, "total_count": 0}

    all_reviews: list[dict] = []
    first = extract_reviews(soup)
    if not first:
        raise SystemExit("この商品にはレビューがありません")
    all_reviews.extend(first)
    emit(f"  [1/{total_pages}] {len(first)}件取得 (累計 {len(all_reviews)})", 1, total_pages)

    try:
        for page in range(2, total_pages + 1):
            time.sleep(SLEEP_BASE + random.random() * SLEEP_JITTER)
            soup = fetch_review_page(shop_id, item_id, page, session)
            if soup is None:
                emit(f"  [{page}/{total_pages}] 取得失敗。ここで打ち切り", page, total_pages)
                break
            page_reviews = extract_reviews(soup)
            if not page_reviews:
                emit(f"  [{page}/{total_pages}] レビュー0件。終端と判断して終了", page, total_pages)
                break
            all_reviews.extend(page_reviews)
            emit(
                f"  [{page}/{total_pages}] {len(page_reviews)}件取得 (累計 {len(all_reviews)})",
                page, total_pages,
            )
    except KeyboardInterrupt:
        emit("\n中断されました。ここまでで保存します。")
    except requests.RequestException as e:
        emit(f"\nリクエストエラー: {e}。ここまでで保存します。")

    info = {
        "shop_code": shop_code,
        "item_code": item_code,
        "shop_id": shop_id,
        "item_id": item_id,
        "total_count": total_count,
        "fetched_count": len(all_reviews),
        "item_url": item_url or "",
    }
    return all_reviews, info


def main() -> None:
    parser = argparse.ArgumentParser(description="楽天レビュー全件取得")
    parser.add_argument(
        "url", nargs="?",
        help="楽天商品URL (例: https://item.rakuten.co.jp/＜店舗ID＞/＜商品ID＞/)。"
             "--shop-id/--item-id で直接指定する場合は省略可",
    )
    parser.add_argument("--shop-id", help="数値shop_id (URL解決をスキップ)")
    parser.add_argument("--item-id", help="数値item_id (URL解決をスキップ)")
    parser.add_argument(
        "--max-pages", type=int, default=None,
        help="取得する最大ページ数 (1ページ=30件)。デフォルト: 全件",
    )
    parser.add_argument(
        "--analyze", action="store_true",
        help="取得後にanalyze_reviews.pyを連続実行",
    )
    args = parser.parse_args()

    if not args.url and not (args.shop_id and args.item_id):
        parser.error("商品URL、または --shop-id と --item-id の両方を指定してください。")

    reviews, info = fetch_all(
        args.url, max_pages=args.max_pages,
        shop_id=args.shop_id, item_id=args.item_id,
    )
    if not reviews:
        print("レビューが0件のため終了します。")
        return

    out_dir = make_output_dir(info["shop_code"], info["item_code"])
    csv_path = out_dir / "reviews_raw.csv"
    write_reviews_csv(reviews, csv_path)
    print(f"\n保存しました: {csv_path}")
    print(f"  取得件数: {len(reviews)} / 総件数: {info.get('total_count')}")

    # メタ情報を一緒に保存
    meta_path = out_dir / "fetch_meta.txt"
    with open(meta_path, "w", encoding="utf-8") as f:
        for k, v in info.items():
            f.write(f"{k}: {v}\n")
        f.write(f"fetched_at: {datetime.now().isoformat(timespec='seconds')}\n")

    if args.analyze:
        script = Path(__file__).parent / "analyze_reviews.py"
        print(f"\n--- 分析開始: {script.name} {csv_path} ---")
        subprocess.run([sys.executable, str(script), str(csv_path)], check=False)


if __name__ == "__main__":
    main()
