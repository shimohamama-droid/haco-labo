#!/bin/bash
# このファイルをダブルクリックすると Streamlit アプリが起動します。
# 初回は自動でセットアップ（venv作成 + ライブラリインストール）が走ります。

cd "$(dirname "$0")"

# venv がなければ作る
if [ ! -d venv ]; then
  echo "[初回セットアップ] Python仮想環境を作成しています..."
  python3 -m venv venv
  ./venv/bin/pip install --upgrade pip
  ./venv/bin/pip install -r requirements.txt
fi
source venv/bin/activate

# .env チェック
if [ ! -f .env ]; then
  echo ""
  echo "[注意] .env ファイルがありません。"
  echo ".env.example をコピーして .env を作り、ANTHROPIC_API_KEY を設定してください。"
  echo "（レビュー取得だけならキーなしでも動きますが、AI分析にはキーが必要です）"
  echo ""
fi

echo ""
echo "=========================================="
echo "  楽天レビュー分析ツールを起動します"
echo "  ブラウザが自動で開きます (localhost:8501)"
echo "  終了するには このウィンドウを閉じる か Ctrl+C"
echo "=========================================="
echo ""

streamlit run app.py
