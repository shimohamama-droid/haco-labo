"""Claude APIでレビューを分析しCSV4本を出力するスクリプト.

使い方:
    python analyze_reviews.py review_outputs/2026-05-04_<shop>_<item>/reviews_raw.csv

出力(同じディレクトリ内):
    analysis_negative.csv  ネガティブTOP20(件数が少なければ全件)
    analysis_positive.csv  ポジティブTOP20(件数が少なければ全件)
    analysis_words.csv     自然発生ワード(単語+フレーズ)
    summary.csv            全体サマリー
    claude_responses/      Claudeの生レスポンス(デバッグ用)
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

# .env から API キー読込み(rakuten_analysis/.env を優先)
ENV_PATH = Path(__file__).parent / ".env"
# override=True: 親プロセスで空文字に上書きされてるケース対策
if ENV_PATH.exists():
    load_dotenv(ENV_PATH, override=True)
else:
    load_dotenv(override=True)

from anthropic import Anthropic  # noqa: E402

DEFAULT_MODEL = "claude-sonnet-4-6"
BATCH_SIZE = 60  # 1バッチあたりのレビュー件数(50〜100目安)
TOP_N = 20
MAX_RETRIES = 3


# ─────────────────────────────────────────────────────────────
# I/O
# ─────────────────────────────────────────────────────────────


def read_reviews(csv_path: Path) -> list[dict]:
    with open(csv_path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        rows = []
        for r in reader:
            try:
                r["rating"] = int(r["rating"]) if r.get("rating") else None
            except ValueError:
                r["rating"] = None
            try:
                r["char_count"] = int(r["char_count"]) if r.get("char_count") else 0
            except ValueError:
                r["char_count"] = 0
            rows.append(r)
    return rows


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


# ─────────────────────────────────────────────────────────────
# Claude API helpers
# ─────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """\
あなたは楽天市場のレビューを読み解く分析アシスタントです。
以下のルールを厳守してください:

- 出力は必ず指示されたJSON形式のみ。前置きや解説は一切不要。
- 「直接引用(quote)」は元レビューの字句通りに切り出す。意訳・要約・捏造は禁止。
  「…」での省略は可だが、語句の追加は禁止。
- summary(要旨)は20字以内、quoteは50字以内、sample_quoteは60字以内。
- 該当レビューが少ない場合は無理に水増しせず、見つかった件数だけ返す。
- 「魔法の袋」「赤ちゃんの体重が消える」のような、お客様が自然に発した
  印象的・具体的な表現を高く評価する。メーカー側の宣伝文句は除外。
"""


def _client() -> Anthropic:
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise SystemExit("ANTHROPIC_API_KEY が見つかりません(.env を確認してください)")
    return Anthropic(api_key=api_key)


def _call_claude(
    client: Anthropic, model: str, prompt: str, log_path: Optional[Path] = None
) -> str:
    last_err: Optional[Exception] = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = client.messages.create(
                model=model,
                max_tokens=8000,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
            )
            text = "".join(b.text for b in resp.content if hasattr(b, "text"))
            if log_path:
                log_path.write_text(text, encoding="utf-8")
            return text
        except Exception as e:  # noqa: BLE001 — anthropic raises various exc types
            last_err = e
            wait = 2 ** attempt
            print(f"  [warn] Claude呼び出し失敗(attempt {attempt}): {e} → {wait}秒待機", file=sys.stderr)
            time.sleep(wait)
    raise RuntimeError(f"Claude API 呼び出しが {MAX_RETRIES}回連続で失敗: {last_err}")


def _parse_json(text: str) -> dict:
    """Claudeのレスポンス文字列からJSONオブジェクトを取り出す."""
    # ```json ... ``` で囲まれていれば剥がす
    m = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.DOTALL)
    if m:
        text = m.group(1)
    # 先頭の{ から末尾の} までを切り出す(末尾余計な文字対策)
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        text = text[start : end + 1]
    return json.loads(text)


# ─────────────────────────────────────────────────────────────
# Batch prompts
# ─────────────────────────────────────────────────────────────


def _format_review_block(reviews: list[dict]) -> str:
    """レビュー本文をプロンプトに埋め込みやすい形に整形."""
    lines = []
    for r in reviews:
        lines.append(
            f"[{r['review_id']}] ★{r['rating']} ({r['posted_date']}) "
            f"variation={r.get('variation') or '-'}\n{r['body']}\n"
        )
    return "\n---\n".join(lines)


BATCH_PROMPT = """\
以下のレビュー群を読み、3つの観点で抽出してJSONで返してください。
レビュー件数: {n}件 (バッチ {batch_idx}/{batch_total})

# 抽出1: ネガティブ候補(不満・後悔・失望系)
- 評価★1〜2を中心に、感情強度の高い不満を全件抽出(★3でも明確に不満があれば含む)。
- 各候補の severity (high/medium/low), category (商品/配送/対応/その他)。

# 抽出2: ポジティブ候補(満足・感動・推奨系)
- 「良かった」程度ではなく、感情の強度が高いもの・体験が具体的なものを優先。
- intensity (very_high/high/medium), category (機能/使用感/感動エピソード/コスパ/接客/その他)。
- 自然発生ワードを含むレビューは優先度を上げる。

# 抽出3: 自然発生ワード(単語+フレーズ)
- お客様が自然に使った印象的な言葉・比喩。メーカーのキャッチコピーは除外。
- 汎用的な「良い」「悪い」「おすすめ」は除外。
- 単語(word)とフレーズ(phrase)を区別。フレーズは2〜15字程度の塊。
- 同じバッチ内で2件以上に登場するものを優先(1件しか出ないものは含めなくて良い)。

出力JSONスキーマ:
{{
  "negatives": [
    {{"review_id": "rNNNNN", "severity": "high|medium|low",
      "category": "商品|配送|対応|その他", "summary": "20字以内", "quote": "50字以内"}}
  ],
  "positives": [
    {{"review_id": "rNNNNN", "intensity": "very_high|high|medium",
      "category": "機能|使用感|感動エピソード|コスパ|接客|その他",
      "summary": "20字以内", "quote": "50字以内"}}
  ],
  "words": [
    {{"type": "word|phrase", "word": "該当の単語またはフレーズ",
      "review_ids": ["rNNNNN", ...], "sample_quote": "60字以内"}}
  ]
}}

JSON以外を出力しないでください。

【レビュー】
{block}
"""


FINAL_RANK_PROMPT = """\
以下は複数バッチで抽出された{kind}候補です(全 {n} 件)。
これらから最終的な TOP{top} を選び、ランキング順に並べ替えて返してください。
- 同じ趣旨の候補は重複統合(代表1件のみ残す)。
- {kind_field}の高さ・体験の具体性・自然発生ワードの含有を重視。
- 候補が {top} 件未満ならその件数のまま返す。

入力フィールドはそのまま保ち、先頭に rank (1始まり) を付けてください。

出力JSONスキーマ:
{{"items": [ {{"rank": 1, ... 元の全フィールド ... }}, ... ] }}

【候補一覧(JSON)】
{candidates}
"""


def analyze_batch(
    client: Anthropic, model: str, reviews: list[dict],
    batch_idx: int, batch_total: int, log_dir: Path,
) -> dict:
    block = _format_review_block(reviews)
    prompt = BATCH_PROMPT.format(
        n=len(reviews), batch_idx=batch_idx, batch_total=batch_total, block=block
    )
    log_path = log_dir / f"batch_{batch_idx:03d}.txt"
    text = _call_claude(client, model, prompt, log_path=log_path)
    try:
        return _parse_json(text)
    except json.JSONDecodeError as e:
        print(f"  [error] バッチ{batch_idx}のJSONパース失敗: {e}", file=sys.stderr)
        print(f"  生レスポンス: {log_path}", file=sys.stderr)
        return {"negatives": [], "positives": [], "words": []}


def rank_topn(
    client: Anthropic, model: str, candidates: list[dict],
    kind: str, kind_field: str, log_dir: Path,
) -> list[dict]:
    if not candidates:
        return []
    if len(candidates) <= TOP_N:
        # ランキングが必要ない件数 — そのまま rank を付与
        return [{**c, "rank": i} for i, c in enumerate(candidates, 1)]

    prompt = FINAL_RANK_PROMPT.format(
        kind=kind, kind_field=kind_field, n=len(candidates), top=TOP_N,
        candidates=json.dumps(candidates, ensure_ascii=False),
    )
    log_path = log_dir / f"final_{kind}.txt"
    text = _call_claude(client, model, prompt, log_path=log_path)
    try:
        data = _parse_json(text)
        return data.get("items", [])
    except json.JSONDecodeError as e:
        print(f"  [error] 最終{kind}ランキングのJSONパース失敗: {e}", file=sys.stderr)
        # フォールバック: 元順序で先頭TOP_N
        return [{**c, "rank": i} for i, c in enumerate(candidates[:TOP_N], 1)]


# ─────────────────────────────────────────────────────────────
# Aggregations
# ─────────────────────────────────────────────────────────────


def merge_words(batch_words_list: list[list[dict]]) -> list[dict]:
    """バッチ毎のwords結果を統合. frequency は出現したユニークなreview_id数."""
    bucket: dict[tuple[str, str], dict] = {}
    for words in batch_words_list:
        for w in words:
            key = (w.get("type", ""), (w.get("word") or "").strip())
            if not key[1]:
                continue
            entry = bucket.setdefault(
                key,
                {
                    "type": key[0], "word": key[1],
                    "review_ids": set(), "sample_quote": "",
                },
            )
            for rid in w.get("review_ids") or []:
                entry["review_ids"].add(rid)
            if not entry["sample_quote"] and w.get("sample_quote"):
                entry["sample_quote"] = w["sample_quote"]

    merged: list[dict] = []
    for entry in bucket.values():
        ids = sorted(entry["review_ids"])
        freq = len(ids)
        if freq < 2:
            continue
        if len(ids) > 10:
            id_str = ",".join(ids[:10]) + f",...他{len(ids) - 10}件"
        else:
            id_str = ",".join(ids)
        merged.append(
            {
                "type": entry["type"], "word": entry["word"], "frequency": freq,
                "sample_quote": entry["sample_quote"], "review_ids": id_str,
            }
        )
    # 並び順: type(word→phrase順) → frequency降順 → word
    type_order = {"word": 0, "phrase": 1}
    merged.sort(key=lambda x: (-x["frequency"], type_order.get(x["type"], 9), x["word"]))
    for i, m in enumerate(merged, 1):
        m["rank"] = i
    return merged


def attach_meta(items: list[dict], reviews_by_id: dict[str, dict]) -> list[dict]:
    """ranking結果に rating/posted_date を補足."""
    for it in items:
        rid = it.get("review_id", "")
        src = reviews_by_id.get(rid)
        if src:
            it["rating"] = src.get("rating")
            it["posted_date"] = src.get("posted_date")
        else:
            it.setdefault("rating", "")
            it.setdefault("posted_date", "")
    return items


def compute_summary(
    reviews: list[dict], n_neg: int, n_pos: int,
    n_words: int, n_phrases: int, item_url: str,
) -> list[dict]:
    n = len(reviews)
    ratings = [r["rating"] for r in reviews if isinstance(r.get("rating"), int)]
    avg = round(sum(ratings) / len(ratings), 1) if ratings else 0.0
    dist = Counter(ratings)
    rows = [
        {"metric": "総レビュー件数", "value": n},
        {"metric": "平均評価点", "value": avg},
        {"metric": "★5件数", "value": dist.get(5, 0)},
        {"metric": "★4件数", "value": dist.get(4, 0)},
        {"metric": "★3件数", "value": dist.get(3, 0)},
        {"metric": "★2件数", "value": dist.get(2, 0)},
        {"metric": "★1件数", "value": dist.get(1, 0)},
        {"metric": "ポジティブ判定件数(★4-5)", "value": dist.get(4, 0) + dist.get(5, 0)},
        {"metric": "ネガティブ判定件数(★1-2)", "value": dist.get(1, 0) + dist.get(2, 0)},
        {"metric": "ニュートラル判定件数(★3)", "value": dist.get(3, 0)},
        {"metric": "ネガTOP抽出件数", "value": n_neg},
        {"metric": "ポジTOP抽出件数", "value": n_pos},
        {"metric": "自然発生ワード総数", "value": n_words + n_phrases},
        {"metric": "  うち単語", "value": n_words},
        {"metric": "  うちフレーズ", "value": n_phrases},
        {"metric": "分析実行日時", "value": datetime.now().isoformat(timespec="seconds")},
        {"metric": "元商品URL", "value": item_url},
    ]
    return rows


# ─────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────


def _read_meta(csv_path: Path) -> dict:
    meta_path = csv_path.parent / "fetch_meta.txt"
    info: dict = {}
    if meta_path.exists():
        for line in meta_path.read_text(encoding="utf-8").splitlines():
            if ":" in line:
                k, _, v = line.partition(":")
                info[k.strip()] = v.strip()
    return info


def analyze_csv(
    csv_path: Path,
    model: str = DEFAULT_MODEL,
    batch_size: int = BATCH_SIZE,
    max_reviews: Optional[int] = None,
    progress=None,
) -> dict:
    """CSVを読んで4本のCSVを書き出す.

    progress: callable(message: str, current: int|None, total: int|None) -> None
    戻り値: {'neg_top':..., 'pos_top':..., 'words':..., 'summary':..., 'out_dir':Path}
    """
    def emit(msg: str, current: Optional[int] = None, total: Optional[int] = None) -> None:
        if progress:
            progress(msg, current, total)
        else:
            print(msg)

    csv_path = Path(csv_path).resolve()
    if not csv_path.exists():
        raise SystemExit(f"CSVが見つかりません: {csv_path}")

    out_dir = csv_path.parent
    log_dir = out_dir / "claude_responses"
    log_dir.mkdir(exist_ok=True)

    reviews = read_reviews(csv_path)
    if max_reviews:
        reviews = reviews[:max_reviews]
    if not reviews:
        raise SystemExit("レビューが0件です")

    emit(f"対象レビュー: {len(reviews)}件 / モデル: {model}")
    reviews_by_id = {r["review_id"]: r for r in reviews}

    client = _client()

    batches = [reviews[i : i + batch_size] for i in range(0, len(reviews), batch_size)]
    all_neg: list[dict] = []
    all_pos: list[dict] = []
    all_words: list[list[dict]] = []
    for i, batch in enumerate(batches, 1):
        emit(f"  バッチ {i}/{len(batches)} ({len(batch)}件) 分析中...", i - 1, len(batches) + 2)
        result = analyze_batch(client, model, batch, i, len(batches), log_dir)
        all_neg.extend(result.get("negatives") or [])
        all_pos.extend(result.get("positives") or [])
        all_words.append(result.get("words") or [])
        if i < len(batches):
            time.sleep(1.0)

    emit("ネガティブ TOP ランキング決定中...", len(batches), len(batches) + 2)
    neg_top = rank_topn(client, model, all_neg, "ネガティブ", "severity", log_dir)
    emit("ポジティブ TOP ランキング決定中...", len(batches) + 1, len(batches) + 2)
    pos_top = rank_topn(client, model, all_pos, "ポジティブ", "intensity", log_dir)

    neg_top = attach_meta(neg_top, reviews_by_id)
    pos_top = attach_meta(pos_top, reviews_by_id)

    emit("自然発生ワードの集計...", len(batches) + 2, len(batches) + 2)
    words = merge_words(all_words)
    n_word = sum(1 for w in words if w["type"] == "word")
    n_phrase = sum(1 for w in words if w["type"] == "phrase")

    write_csv(
        out_dir / "analysis_negative.csv", neg_top,
        ["rank", "severity", "category", "summary", "review_id", "rating", "posted_date", "quote"],
    )
    write_csv(
        out_dir / "analysis_positive.csv", pos_top,
        ["rank", "intensity", "category", "summary", "review_id", "rating", "posted_date", "quote"],
    )
    write_csv(
        out_dir / "analysis_words.csv", words,
        ["rank", "type", "word", "frequency", "review_ids", "sample_quote"],
    )

    meta = _read_meta(csv_path)
    item_url = meta.get("item_url", "")
    summary_rows = compute_summary(reviews, len(neg_top), len(pos_top), n_word, n_phrase, item_url)
    write_csv(out_dir / "summary.csv", summary_rows, ["metric", "value"])

    emit(f"完了。出力先: {out_dir}")
    return {
        "neg_top": neg_top, "pos_top": pos_top, "words": words,
        "summary": summary_rows, "out_dir": out_dir,
        "n_word": n_word, "n_phrase": n_phrase,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Claudeで楽天レビューを分析")
    parser.add_argument("csv", help="reviews_raw.csv のパス")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"使用モデル(デフォルト: {DEFAULT_MODEL})")
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    parser.add_argument("--max-reviews", type=int, default=None,
                        help="解析対象を先頭N件に絞る(動作確認用)")
    args = parser.parse_args()

    result = analyze_csv(
        Path(args.csv), model=args.model,
        batch_size=args.batch_size, max_reviews=args.max_reviews,
    )
    out_dir = result["out_dir"]
    print(f"\n完了。出力先: {out_dir}")
    print(f"  analysis_negative.csv  ({len(result['neg_top'])}件)")
    print(f"  analysis_positive.csv  ({len(result['pos_top'])}件)")
    print(f"  analysis_words.csv     ({len(result['words'])}件 / 単語{result['n_word']} + フレーズ{result['n_phrase']})")
    print(f"  summary.csv")


if __name__ == "__main__":
    main()
