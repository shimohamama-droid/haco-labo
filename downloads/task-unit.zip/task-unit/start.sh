#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"

# Backend
cd "$ROOT/backend"
if [ ! -d .venv ]; then
  echo "[setup] creating venv..."
  /opt/homebrew/bin/python3.12 -m venv .venv || python3 -m venv .venv
  ./.venv/bin/pip install --upgrade pip
  ./.venv/bin/pip install -r requirements.txt
fi
[ -f .env ] || cp .env.example .env

echo "[backend] starting on :8001"
./.venv/bin/uvicorn main:app --host 127.0.0.1 --port 8001 --reload &
BACK_PID=$!

# Frontend
cd "$ROOT/frontend"
if [ ! -d node_modules ]; then
  echo "[setup] installing npm deps..."
  npm install
fi
echo "[frontend] starting on :5173"
npm run dev &
FRONT_PID=$!

trap "kill $BACK_PID $FRONT_PID 2>/dev/null" EXIT
echo ""
echo "================================================="
echo "  Task-Unit running:"
echo "    Frontend: http://localhost:5173"
echo "    Backend:  http://127.0.0.1:8001"
echo "  Ctrl+C で停止"
echo "================================================="
wait
