// 本番デプロイ時は VITE_API_BASE にAPIのURLを設定。
// ローカルdev時は空文字 → vite proxy 経由で localhost:8001 のFastAPIに行く。
const base = import.meta.env.VITE_API_BASE || '';

async function req(path, opts = {}) {
  const res = await fetch(base + path, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
  if (res.status === 204) return null;
  return res.json();
}

export const api = {
  // tasks
  listTasks: (view) => req(`/api/tasks?view=${view}`),
  summary: () => req('/api/tasks/summary'),
  createTask: (data) => req('/api/tasks', { method: 'POST', body: JSON.stringify(data) }),
  patchTask: (id, data) => req(`/api/tasks/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteTask: (id) => req(`/api/tasks/${id}`, { method: 'DELETE' }),
  moveToToday: (id) => req(`/api/tasks/${id}/move-to-today`, { method: 'POST' }),
  moveAllToToday: () => req('/api/tasks/move-all-to-today', { method: 'POST' }),
  taskToNote: (id) => req(`/api/tasks/${id}/convert-to-note`, { method: 'POST' }),
  predictMinutes: (data) =>
    req('/api/predict-minutes', { method: 'POST', body: JSON.stringify(data) }),

  // notes
  listNotes: () => req('/api/notes'),
  createNote: (data) => req('/api/notes', { method: 'POST', body: JSON.stringify(data) }),
  patchNote: (id, data) => req(`/api/notes/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteNote: (id) => req(`/api/notes/${id}`, { method: 'DELETE' }),
  noteToTask: (id) => req(`/api/notes/${id}/convert-to-task`, { method: 'POST' }),

  // boards / cards
  listBoards: () => req('/api/boards'),
  listCards: (boardId) => req(`/api/boards/${boardId}/cards`),
  createCard: (data) => req('/api/cards', { method: 'POST', body: JSON.stringify(data) }),
  patchCard: (id, data) => req(`/api/cards/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteCard: (id) => req(`/api/cards/${id}`, { method: 'DELETE' }),
  cardToTask: (id) => req(`/api/cards/${id}/convert-to-task`, { method: 'POST' }),

  // v0.1: 指示書 + actor
  listActors: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return req('/api/actors' + (q ? '?' + q : ''));
  },
  createInstruction: (data) =>
    req('/api/instructions', { method: 'POST', body: JSON.stringify(data) }),
  assignCard: (id, data) =>
    req(`/api/cards/${id}/assign`, { method: 'POST', body: JSON.stringify(data) }),
  transitionCard: (id, data) =>
    req(`/api/cards/${id}/transition`, { method: 'POST', body: JSON.stringify(data) }),
  cardHistory: (id) => req(`/api/cards/${id}/history`),
  todayMissions: (actorId) => req(`/api/today-missions/${actorId}`),

  // reviews
  yesterdayReview: () => req('/api/reviews/yesterday'),
  saveReview: (data) => req('/api/reviews', { method: 'POST', body: JSON.stringify(data) }),
};
