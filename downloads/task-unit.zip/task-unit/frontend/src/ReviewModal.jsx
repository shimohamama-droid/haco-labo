import React, { useState } from 'react';
import { api } from './api.js';

export default function ReviewModal({ data, onClose, onSaved }) {
  const [notes, setNotes] = useState('');

  async function save() {
    await api.saveReview({
      review_date: data.review_date,
      total_minutes: data.total_minutes,
      completed_count: data.completed_tasks.length,
      notes,
    });
    if (onSaved) onSaved();
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2>昨日の振り返り（{data.review_date}）</h2>
        <div className="row">
          <label>完了タスク {data.completed_tasks.length} 件</label>
          {data.completed_tasks.length === 0 ? (
            <div className="empty">完了タスクなし</div>
          ) : (
            <ul style={{ paddingLeft: 18, margin: '4px 0' }}>
              {data.completed_tasks.map((t) => (
                <li key={t.id}>
                  {t.title}
                  {t.actual_minutes ? ` (${t.actual_minutes}分)` : ''}
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="row">
          <label>合計作業時間</label>
          <div style={{ fontWeight: 600 }}>{fmtH(data.total_minutes)}</div>
        </div>
        <div className="row">
          <label>一言メモ（任意・参謀君に渡す用）</label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="今日の気づき、明日に持ち越すこと、など"
          />
        </div>
        <div className="actions">
          <button onClick={onClose}>あとで</button>
          <button className="primary" onClick={save}>
            保存
          </button>
        </div>
      </div>
    </div>
  );
}

function fmtH(mins) {
  if (!mins) return '0h';
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m ? `${h}時間${m}分` : `${h}時間`;
}
