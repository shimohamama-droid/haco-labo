// プロジェクトカラーマップ
export const CATEGORIES = [
  '仕事',
  'プロジェクト',
  '学び',
  '私生活',
];

export const TYPE_TAGS = [
  'コーディング',
  'ドキュメント',
  'ミーティング',
  'デザイン',
  'レビュー',
  'その他',
];

const COLOR_CLASS = {
  '仕事': 'proj-akoako',        // 青
  'プロジェクト': 'proj-haco',   // 緑
  '学び': 'proj-fukugyo',       // オレンジ
  '私生活': 'proj-private',     // 黄
};

export function projectClass(category) {
  return COLOR_CLASS[category] || 'proj-default';
}

export function formatTime(actual, estimated) {
  const a = actual ? (actual / 60).toFixed(actual % 60 ? 1 : 0) : null;
  const e = estimated ? (estimated / 60).toFixed(estimated % 60 ? 1 : 0) : null;
  if (a && e) return `${a}/${e}h`;
  if (a) return `${a}h`;
  if (e) return `${e}h`;
  return '';
}

export function formatHours(mins) {
  if (!mins) return '0h';
  const h = mins / 60;
  return h % 1 ? `${h.toFixed(1)}h` : `${h}h`;
}
