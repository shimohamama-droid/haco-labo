import React, { useEffect, useMemo, useState } from 'react';
import { api } from './api.js';
import TasksPage from './TasksPage.jsx';
import BoardsPage from './BoardsPage.jsx';
import CalendarPage from './CalendarPage.jsx';
import ReviewModal from './ReviewModal.jsx';

export default function App() {
  const [page, setPage] = useState('tasks');
  const [reviewOpen, setReviewOpen] = useState(false);
  const [reviewData, setReviewData] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    // 起動時に昨日の振り返りを取得
    (async () => {
      try {
        const data = await api.yesterdayReview();
        const shownKey = `taskunit-review-shown-${data.review_date}`;
        if (
          data.completed_tasks.length > 0 &&
          !data.existing_review &&
          !localStorage.getItem(shownKey)
        ) {
          setReviewData(data);
          setReviewOpen(true);
          localStorage.setItem(shownKey, '1');
        }
      } catch (e) {
        console.error(e);
      }
    })();
  }, []);

  async function openReview() {
    try {
      const d = await api.yesterdayReview();
      setReviewData(d);
      setReviewOpen(true);
    } catch (e) {
      alert('Review データ取得失敗: ' + e.message);
    }
  }

  return (
    <div>
      <header className="topbar">
        <div className="brand">
          <span>TASK-UNIT</span>
          <span className="ver">v0.1</span>
          <button className="review-btn" onClick={openReview}>📓 振り返り</button>
        </div>
        <nav className="nav">
          <button
            className={page === 'tasks' ? 'active' : ''}
            onClick={() => setPage('tasks')}
          >
            📅 Tasks
          </button>
          <button
            className={page === 'boards' ? 'active' : ''}
            onClick={() => setPage('boards')}
          >
            🗂 Boards
          </button>
          <button
            className={page === 'calendar' ? 'active' : ''}
            onClick={() => setPage('calendar')}
          >
            📆 Calendar
          </button>
        </nav>
      </header>

      {page === 'tasks' && <TasksPage refreshKey={refreshKey} />}
      {page === 'boards' && <BoardsPage />}
      {page === 'calendar' && <CalendarPage />}

      {reviewOpen && reviewData && (
        <ReviewModal
          data={reviewData}
          onClose={() => setReviewOpen(false)}
          onSaved={() => {
            setReviewOpen(false);
            setRefreshKey((k) => k + 1);
          }}
        />
      )}
    </div>
  );
}
