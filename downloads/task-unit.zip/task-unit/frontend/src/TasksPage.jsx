import React, { useEffect, useMemo, useState } from 'react';
import { api } from './api.js';
import { CATEGORIES, TYPE_TAGS, projectClass, formatTime, formatHours } from './projects.js';
import NotesPanel from './NotesPanel.jsx';

export default function TasksPage({ refreshKey }) {
  const [today, setToday] = useState([]);
  const [overdue, setOverdue] = useState([]);
  const [upcoming, setUpcoming] = useState([]);
  const [summary, setSummary] = useState(null);
  const [selected, setSelected] = useState(null);
  const [newTitle, setNewTitle] = useState('');
  const [notesRefresh, setNotesRefresh] = useState(0);

  async function reload() {
    const [t, o, u, s] = await Promise.all([
      api.listTasks('today'),
      api.listTasks('overdue'),
      api.listTasks('upcoming'),
      api.summary(),
    ]);
    setToday(t);
    setOverdue(o);
    setUpcoming(u);
    setSummary(s);
  }

  useEffect(() => {
    reload();
  }, [refreshKey]);

  // ショートカット解析
  function parseShortcuts(text) {
    const parts = text.split(/\s+/);
    const out = { title: [], category: null, type_tag: null, estimated_minutes: null, scheduled_date: null };
    for (const p of parts) {
      if (p.startsWith(':') && p.length > 1) out.category = p.slice(1);
      else if (p.startsWith('#') && p.length > 1) out.type_tag = p.slice(1);
      else if (p.startsWith('!') && p.length > 1) {
        const n = parseInt(p.slice(1), 10);
        if (!isNaN(n)) out.estimated_minutes = n;
      } else if (p.startsWith('/') && p.length > 1) {
        const v = p.slice(1);
        if (v === 'tomorrow' || v === '明日') {
          const d = new Date();
          d.setDate(d.getDate() + 1);
          out.scheduled_date = d.toISOString().slice(0, 10);
        } else if (/^\d{4}-\d{2}-\d{2}$/.test(v)) {
          out.scheduled_date = v;
        }
      } else {
        out.title.push(p);
      }
    }
    out.title = out.title.join(' ').trim();
    return out;
  }

  async function addTask() {
    if (!newTitle.trim()) return;
    const parsed = parseShortcuts(newTitle);
    if (!parsed.title) return;
    await api.createTask({
      title: parsed.title,
      category: parsed.category,
      type_tag: parsed.type_tag,
      estimated_minutes: parsed.estimated_minutes || null,
      scheduled_date: parsed.scheduled_date,
    });
    setNewTitle('');
    reload();
  }

  async function toggleDone(task) {
    const next = task.status === 'done' ? 'todo' : 'done';
    const patch = { status: next };
    if (next === 'done' && !task.actual_minutes && task.estimated_minutes) {
      patch.actual_minutes = task.estimated_minutes;
    }
    await api.patchTask(task.id, patch);
    reload();
  }

  async function moveToToday(id) {
    await api.moveToToday(id);
    reload();
  }

  async function moveAll() {
    if (!overdue.length) return;
    await api.moveAllToToday();
    reload();
  }

  async function updateField(id, field, value) {
    await api.patchTask(id, { [field]: value });
    if (selected && selected.id === id) setSelected({ ...selected, [field]: value });
    reload();
  }

  async function deleteTask(id, e) {
    e?.stopPropagation();
    if (!confirm('削除しますか？')) return;
    await api.deleteTask(id);
    if (selected && selected.id === id) setSelected(null);
    reload();
  }

  async function taskToNote(task) {
    await api.taskToNote(task.id);
    setNotesRefresh((k) => k + 1);
  }

  // 進捗バー値計算
  const progressPct = useMemo(() => {
    if (!summary) return 0;
    if (summary.today_estimated_minutes > 0) {
      return Math.min(100, (summary.today_minutes / summary.today_estimated_minutes) * 100);
    }
    if (summary.today_total > 0) {
      return (summary.today_done / summary.today_total) * 100;
    }
    return 0;
  }, [summary]);

  const dateLabel = useMemo(() => {
    const d = new Date();
    const wd = ['日', '月', '火', '水', '木', '金', '土'][d.getDay()];
    return `${d.getMonth() + 1}/${d.getDate()} (${wd})`;
  }, []);

  return (
    <div className="page">
      <div>
        {/* Daily Summary */}
        <div className="summary-card">
          <div className="date">{dateLabel}</div>
          <div className="big-time">
            {formatHours(summary?.today_minutes)}
            <span className="of">/ {formatHours(summary?.today_estimated_minutes)}</span>
          </div>
          <div className="stats">
            完了 {summary?.today_done || 0}/{summary?.today_total || 0}件 · {Math.round(progressPct)}%
            {summary?.overdue > 0 && (
              <span className="overdue" onClick={moveAll} title="まとめて今日に移す">
                · {summary.overdue}件の持ち越し
              </span>
            )}
          </div>
          <div className="pbar"><div style={{ width: `${progressPct}%` }} /></div>
        </div>

        {/* Quick Add */}
        <div className="quick-add">
          <span className="plus">＋</span>
          <input
            placeholder="タスクを追加（:#!/ でショートカット）"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addTask()}
          />
          <button className="add" onClick={addTask}>追加</button>
        </div>
        <div className="quick-add-hint">
          例: <code>:HACO</code> <code>#ドキュメント</code> <code>!60</code> <code>/tomorrow</code>
        </div>

        {/* Today */}
        <div className="section-head">
          <h2>今日のタスク <span className="count">{today.length}</span></h2>
        </div>
        <div className="task-list">
          {today.length === 0 && <div className="empty">今日のタスクなし</div>}
          {today.map((t) => (
            <TaskRow
              key={t.id}
              task={t}
              selected={selected?.id === t.id}
              onToggle={() => toggleDone(t)}
              onSelect={() => setSelected(t)}
              onDelete={(e) => deleteTask(t.id, e)}
            />
          ))}
        </div>

        {/* Overdue */}
        {overdue.length > 0 && (
          <>
            <div className="section-head">
              <h2 className="overdue-title">持ち越しタスク <span className="count">{overdue.length}</span></h2>
              <button className="move-all" onClick={moveAll}>すべて今日に移す ▾</button>
            </div>
            <div className="task-list">
              {overdue.map((t) => (
                <TaskRow
                  key={t.id}
                  task={t}
                  selected={selected?.id === t.id}
                  onToggle={() => toggleDone(t)}
                  onSelect={() => setSelected(t)}
                  onDelete={(e) => deleteTask(t.id, e)}
                  extraAction={
                    <button
                      className="move-today"
                      onClick={(e) => { e.stopPropagation(); moveToToday(t.id); }}
                    >
                      → 今日
                    </button>
                  }
                />
              ))}
            </div>
          </>
        )}

        {/* Upcoming */}
        {upcoming.length > 0 && (
          <>
            <div className="section-head">
              <h2>今後のタスク <span className="count">{upcoming.length}</span></h2>
            </div>
            <div className="task-list">
              {upcoming.map((t) => (
                <TaskRow
                  key={t.id}
                  task={t}
                  selected={selected?.id === t.id}
                  onToggle={() => toggleDone(t)}
                  onSelect={() => setSelected(t)}
                  onDelete={(e) => deleteTask(t.id, e)}
                  showDate
                />
              ))}
            </div>
          </>
        )}
      </div>

      <div className="right-col">
        {selected && (
          <div className="detail-panel">
            <h3 style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              タスク詳細
              <button className="close" onClick={() => setSelected(null)}>閉じる</button>
            </h3>
            <div className="field">
              <label>タイトル</label>
              <input
                key={`t-${selected.id}`}
                defaultValue={selected.title}
                onBlur={(e) => updateField(selected.id, 'title', e.target.value)}
              />
            </div>
            <div className="field">
              <label>カテゴリ</label>
              <select
                value={selected.category || ''}
                onChange={(e) => updateField(selected.id, 'category', e.target.value || null)}
              >
                <option value="">未指定</option>
                {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="field">
              <label>種別</label>
              <select
                value={selected.type_tag || ''}
                onChange={(e) => updateField(selected.id, 'type_tag', e.target.value || null)}
              >
                <option value="">未指定</option>
                {TYPE_TAGS.map((t) => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <div className="field" style={{ flex: 1 }}>
                <label>想定（分）</label>
                <input
                  key={`e-${selected.id}`}
                  type="number"
                  defaultValue={selected.estimated_minutes || ''}
                  onBlur={(e) => updateField(selected.id, 'estimated_minutes', parseInt(e.target.value, 10) || null)}
                />
              </div>
              <div className="field" style={{ flex: 1 }}>
                <label>実績（分）</label>
                <input
                  key={`a-${selected.id}`}
                  type="number"
                  defaultValue={selected.actual_minutes || ''}
                  onBlur={(e) => updateField(selected.id, 'actual_minutes', parseInt(e.target.value, 10) || null)}
                />
              </div>
            </div>
            <div className="field">
              <label>進捗 {selected.progress || 0}%</label>
              <input
                key={`p-${selected.id}`}
                type="range" min="0" max="100" step="10"
                defaultValue={selected.progress || 0}
                onChange={(e) => updateField(selected.id, 'progress', parseInt(e.target.value, 10))}
              />
            </div>
            <div className="field">
              <label>メモ</label>
              <textarea
                key={`d-${selected.id}`}
                defaultValue={selected.description || ''}
                onBlur={(e) => updateField(selected.id, 'description', e.target.value)}
              />
            </div>
            <button
              className="close"
              style={{ background: '#fbe9d6', color: '#a06a3c', padding: '6px 10px' }}
              onClick={() => taskToNote(selected)}
            >
              📋 Notesに複製
            </button>
          </div>
        )}

        <NotesPanel refreshKey={notesRefresh} />
      </div>
    </div>
  );
}

function TaskRow({ task, selected, onToggle, onSelect, onDelete, extraAction, showDate }) {
  const done = task.status === 'done';
  const projCls = projectClass(task.category);
  return (
    <div
      className={`task ${done ? 'done' : ''} ${selected ? 'selected' : ''} ${projCls}`}
      onClick={onSelect}
    >
      <span className="handle" title="ドラッグハンドル（順序変更は今後）">⋮⋮</span>
      <span
        className="status-circle"
        onClick={(e) => { e.stopPropagation(); onToggle(); }}
        title={done ? '完了→未完了' : '完了にする'}
      />
      <span className="title">{task.title}</span>
      <span className="tags">
        {task.category && <span className="tag-proj">{task.category}</span>}
        {task.type_tag && <span className="tag-type">{task.type_tag}</span>}
      </span>
      {showDate && task.scheduled_date && (
        <span style={{ fontSize: 11, color: '#b8aa84' }}>{task.scheduled_date.slice(5)}</span>
      )}
      <span className="time-display">
        {task.actual_minutes && task.estimated_minutes ? (
          <>
            <span className="actual">{(task.actual_minutes / 60).toFixed(task.actual_minutes % 60 ? 1 : 0)}</span>
            /{(task.estimated_minutes / 60).toFixed(task.estimated_minutes % 60 ? 1 : 0)}h
          </>
        ) : (
          formatTime(task.actual_minutes, task.estimated_minutes)
        )}
      </span>
      {extraAction}
      <button className="delete" onClick={onDelete}>×</button>
    </div>
  );
}
