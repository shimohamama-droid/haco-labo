import React, { useEffect, useState } from 'react';
import { api } from './api.js';
import { CATEGORIES, projectClass } from './projects.js';

export default function NotesPanel({ refreshKey }) {
  const [notes, setNotes] = useState([]);
  const [body, setBody] = useState('');
  const [category, setCategory] = useState('');

  async function reload() {
    setNotes(await api.listNotes());
  }

  useEffect(() => {
    reload();
  }, [refreshKey]);

  async function add() {
    if (!body.trim()) return;
    const title = body.split('\n')[0].slice(0, 40);
    await api.createNote({ title, body, category: category || null });
    setBody('');
    reload();
  }

  async function toTask(id) {
    await api.noteToTask(id);
    reload();
  }

  async function del(id) {
    if (!confirm('削除しますか？')) return;
    await api.deleteNote(id);
    reload();
  }

  return (
    <div className="notes-panel">
      <div className="head">
        <h3>Notes</h3>
        <span className="ct">{notes.length}件</span>
      </div>
      <textarea
        className="add"
        placeholder="メモを追加…（最初の行がタイトルになる）"
        value={body}
        onChange={(e) => setBody(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) add();
        }}
      />
      <div className="add-row">
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">プロジェクト</option>
          {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
        <button onClick={add}>投稿</button>
      </div>

      <div style={{ marginTop: 14 }}>
        {notes.length === 0 && <div className="empty">メモなし</div>}
        {notes.map((n) => (
          <div key={n.id} className={`note-item ${projectClass(n.category)}`}>
            <div className="title">{n.title || '(無題)'}</div>
            {n.body && n.body !== n.title && (
              <div className="body">{n.body}</div>
            )}
            <div className="meta">
              {n.category && <span className="tag-proj" style={{ fontSize: 10 }}>{n.category}</span>}
              <span>{(n.created_at || '').slice(5, 16).replace('T', ' ')}</span>
              <span className="actions">
                <button onClick={() => toTask(n.id)} title="タスクに昇格">→タスク化</button>
                <button className="danger" onClick={() => del(n.id)}>×</button>
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
