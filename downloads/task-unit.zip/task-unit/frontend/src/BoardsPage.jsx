import React, { useCallback, useEffect, useRef, useState } from 'react';
import { api } from './api.js';

const COLORS = ['yellow', 'pink', 'skyblue', 'green', 'orange', 'gray'];
const COLOR_HEX = {
  yellow: '#fdf3a6',
  pink: '#ffd0e0',
  skyblue: '#c7e8ff',
  green: '#c9efc1',
  orange: '#ffd6a0',
  gray: '#e2e2dc',
};

// v0.1: actor アイコン & 状態色
function actorIcon(type) {
  if (type === 'human') return '👤';
  if (type === 'ai') return '🤖';
  if (type === 'system') return '⚙️';
  return '';
}
const STATE_COLOR = {
  waiting: '#9E9E9E',
  in_progress: '#2196F3',
  completed: '#4CAF50',
  decision_required: '#FF9800',
  overdue: '#F44336',
  abandoned: '#666',
};
const STATE_LABEL = {
  waiting: '待機',
  in_progress: '進行中',
  completed: '完了',
  decision_required: '判断要請',
  overdue: '期限切れ',
  abandoned: '放置',
};

export default function BoardsPage() {
  const [boards, setBoards] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [cards, setCards] = useState([]);
  const [menu, setMenu] = useState(null);
  const [editing, setEditing] = useState(null); // { cardId, field, value }
  const [fabOpen, setFabOpen] = useState(false);
  const [fabMode, setFabMode] = useState('default'); // 'default' | 'instruction'
  const [actors, setActors] = useState([]);
  const [instForm, setInstForm] = useState({ from: '', to: '', subject: '' });
  const canvasRef = useRef(null);
  const dragState = useRef(null);
  const cardRefs = useRef({});

  useEffect(() => {
    (async () => {
      const bs = await api.listBoards();
      setBoards(bs);
      if (bs.length) setActiveId(bs[0].id);
    })();
  }, []);

  // v0.1: actor マスタを取得
  useEffect(() => {
    (async () => {
      try {
        const list = await api.listActors({ active_only: 'true' });
        setActors(list);
      } catch (e) {
        console.warn('actors load failed', e);
      }
    })();
  }, []);

  useEffect(() => {
    if (activeId) reload();
  }, [activeId]);

  async function reload() {
    setCards(await api.listCards(activeId));
  }

  // ---- Drag with window-level listeners + direct DOM manipulation ----
  const startDrag = useCallback(
    (e, card) => {
      if (editing) return;
      // ignore clicks on buttons/checkboxes
      if (e.target.closest('[data-no-drag]')) return;
      e.preventDefault();
      const el = cardRefs.current[card.id];
      if (!el) return;
      dragState.current = {
        cardId: card.id,
        startX: e.clientX,
        startY: e.clientY,
        origX: card.pos_x,
        origY: card.pos_y,
        el,
        moved: false,
        lastX: card.pos_x,
        lastY: card.pos_y,
      };
      el.classList.add('dragging');
    },
    [editing]
  );

  useEffect(() => {
    function onMove(e) {
      const s = dragState.current;
      if (!s) return;
      const dx = e.clientX - s.startX;
      const dy = e.clientY - s.startY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) s.moved = true;
      const nx = Math.max(0, s.origX + dx);
      const ny = Math.max(0, s.origY + dy);
      s.el.style.left = nx + 'px';
      s.el.style.top = ny + 'px';
      s.lastX = nx;
      s.lastY = ny;
    }
    async function onUp(e) {
      const s = dragState.current;
      if (!s) return;
      s.el.classList.remove('dragging');

      // v0.1: AIサイドバー / その他へのドロップ検知
      // elementsFromPoint で重なり全部見る(ドラッグ中カード自身がトップに来てしまうため)
      if (s.moved && e) {
        const stack = document.elementsFromPoint(e.clientX, e.clientY) || [];
        let aiSection = null;
        let overSidebar = false;
        for (const el of stack) {
          if (!aiSection) {
            const ai = el.closest && el.closest('[data-ai-target]');
            if (ai) aiSection = ai;
          }
          if (!overSidebar) {
            const sb = el.closest && el.closest('.ai-dispatch-sidebar');
            if (sb) overSidebar = true;
          }
          if (aiSection && overSidebar) break;
        }

        if (aiSection) {
          // AIに割り当て: 位置は元に戻す
          const aiId = aiSection.getAttribute('data-ai-target');
          s.el.style.left = s.origX + 'px';
          s.el.style.top = s.origY + 'px';
          dragState.current = null;
          await assignCardToAI(s.cardId, aiId);
          return;
        }

        if (overSidebar) {
          // サイドバー範囲だがAIセクションじゃない場所にドロップ → 位置を元に戻すだけ
          s.el.style.left = s.origX + 'px';
          s.el.style.top = s.origY + 'px';
          dragState.current = null;
          return;
        }
      }

      dragState.current = null;
      if (s.moved) {
        try {
          await api.patchCard(s.cardId, { pos_x: s.lastX, pos_y: s.lastY });
          setCards((prev) =>
            prev.map((c) =>
              c.id === s.cardId ? { ...c, pos_x: s.lastX, pos_y: s.lastY } : c
            )
          );
        } catch (err) {
          console.error('move save failed', err);
        }
      }
    }
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    // activeId / actors / cards を deps に入れる(stale closure防止)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeId, actors, cards]);

  // ---- Inline edit ----
  function startEdit(card, field) {
    setEditing({ cardId: card.id, field, value: card[field] || '' });
  }
  async function commitEdit() {
    if (!editing) return;
    const card = cards.find((c) => c.id === editing.cardId);
    const next = editing;
    setEditing(null);
    if (!card || card[next.field] === next.value) return;
    setCards((prev) =>
      prev.map((c) =>
        c.id === card.id ? { ...c, [next.field]: next.value } : c
      )
    );
    try {
      await api.patchCard(card.id, { [next.field]: next.value });
    } catch (e) {
      console.error('save failed', e);
    }
  }
  function cancelEdit() {
    setEditing(null);
  }

  // ---- Canvas double-click → create card ----
  async function onCanvasDblClick(e) {
    if (e.target !== canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x =
      e.clientX - rect.left + canvasRef.current.scrollLeft;
    const y =
      e.clientY - rect.top + canvasRef.current.scrollTop;
    await api.createCard({
      board_id: activeId,
      card_type: 'idea',
      title: '新規カード',
      body: '',
      color: 'yellow',
      pos_x: Math.max(0, x - 100),
      pos_y: Math.max(0, y - 30),
    });
    reload();
  }

  // ---- FAB（＋丸ボタン）→ create card ----
  function centerPosition() {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 100, y: 100 };
    const sl = canvas.scrollLeft || 0;
    const st = canvas.scrollTop || 0;
    const cw = canvas.clientWidth;
    const ch = canvas.clientHeight;
    const jitterX = Math.round((Math.random() - 0.5) * 60);
    const jitterY = Math.round((Math.random() - 0.5) * 60);
    return {
      x: Math.max(20, Math.round(sl + cw / 2 - 100 + jitterX)),
      y: Math.max(20, Math.round(st + ch / 2 - 60 + jitterY)),
    };
  }

  async function addCardViaFab(opts = {}) {
    const { card_type = 'idea', color = 'yellow' } = opts;
    const { x, y } = centerPosition();
    setFabOpen(false);
    setFabMode('default');
    await api.createCard({
      board_id: activeId,
      card_type,
      title: '',
      body: '',
      color,
      pos_x: x,
      pos_y: y,
    });
    reload();
  }

  // v0.1: ドラッグ&ドロップでカードをAIに割り当て
  async function assignCardToAI(cardId, aiId) {
    try {
      await api.assignCard(cardId, { to_actor_id: aiId });
      reload();
    } catch (e) {
      console.error('割り当て失敗', e);
      alert('割り当て失敗: ' + e.message);
    }
  }

  // v0.1: 指示書カードを作成
  async function createInstructionViaFab() {
    if (!instForm.from) {
      alert('差出人を選択してください');
      return;
    }
    if (!instForm.to) {
      alert('宛先を選択してください');
      return;
    }
    const fromA = actors.find((a) => a.actor_id === instForm.from);
    const toA = actors.find((a) => a.actor_id === instForm.to);
    if (!fromA || !toA) return;
    const { x, y } = centerPosition();
    try {
      await api.createInstruction({
        board_id: activeId,
        subject: instForm.subject || '新規指示書',
        body: '',
        from_actor: {
          actor_type: fromA.actor_type,
          actor_id: fromA.actor_id,
          display_name: fromA.display_name,
        },
        to_actor: {
          actor_type: toA.actor_type,
          actor_id: toA.actor_id,
          display_name: toA.display_name,
        },
        urgency: 'medium',
        color: 'yellow',
        pos_x: x,
        pos_y: y,
      });
      setFabOpen(false);
      setFabMode('default');
      setInstForm({ from: '', to: '', subject: '' });
      reload();
    } catch (e) {
      console.error('指示書作成失敗', e);
      alert('指示書作成に失敗しました: ' + e.message);
    }
  }

  // ---- Card actions ----
  async function toggleDone(card) {
    const next = card.is_completed ? 0 : 1;
    setCards((prev) =>
      prev.map((c) => (c.id === card.id ? { ...c, is_completed: next } : c))
    );
    await api.patchCard(card.id, { is_completed: next });
  }
  async function changeColor(cardId, color) {
    setMenu(null);
    setCards((prev) =>
      prev.map((c) => (c.id === cardId ? { ...c, color } : c))
    );
    await api.patchCard(cardId, { color });
  }
  async function cardToTask(cardId) {
    setMenu(null);
    await api.cardToTask(cardId);
    alert('タスク化しました（Tasks タブで確認）');
  }
  async function deleteCard(cardId) {
    setMenu(null);
    if (!confirm('削除しますか？')) return;
    await api.deleteCard(cardId);
    reload();
  }
  async function toggleType(cardId) {
    setMenu(null);
    const card = cards.find((c) => c.id === cardId);
    if (!card) return;
    const next = card.card_type === 'todo' ? 'idea' : 'todo';
    setCards((prev) =>
      prev.map((c) => (c.id === cardId ? { ...c, card_type: next } : c))
    );
    await api.patchCard(cardId, { card_type: next });
  }

  function openMenu(e, cardId) {
    e.preventDefault();
    e.stopPropagation();
    setMenu({ x: e.clientX, y: e.clientY, cardId });
  }

  useEffect(() => {
    const handler = (e) => {
      // 編集中ならクリック外しでコミット
      if (editing && !e.target.closest('.card-edit-overlay')) {
        commitEdit();
      }
      if (menu && !e.target.closest('.card-menu')) {
        setMenu(null);
      }
    };
    window.addEventListener('mousedown', handler);
    return () => window.removeEventListener('mousedown', handler);
    // eslint-disable-next-line
  }, [editing, menu]);

  const activeBoard = boards.find((b) => b.id === activeId);

  return (
    <div className="boards-page">
      <div className="board-tabs">
        {boards.map((b) => (
          <button
            key={b.id}
            className={b.id === activeId ? 'active' : ''}
            onClick={() => setActiveId(b.id)}
          >
            {b.name}
            {b.is_system ? ' 🔒' : ''}
          </button>
        ))}
      </div>
      <div style={{ fontSize: 12, color: '#888', marginBottom: 8 }}>
        <b>右下の ＋ ボタン</b>で新規カード。カードはドラッグで移動、
        <b>テキストはダブルクリックで編集</b>、右クリックでメニュー。
        {activeBoard?.is_system && (
          <> 中断BOXは「トリガー条件」を本文に明記推奨。</>
        )}
      </div>
      <div className="canvas-wrap">
      <div
        className="board-canvas"
        ref={canvasRef}
        onDoubleClick={onCanvasDblClick}
      >
        {cards.map((c) => {
          const isEditingTitle =
            editing && editing.cardId === c.id && editing.field === 'title';
          const isEditingBody =
            editing && editing.cardId === c.id && editing.field === 'body';
          return (
            <div
              key={c.id}
              ref={(el) => (cardRefs.current[c.id] = el)}
              className={`card color-${c.color} ${c.is_completed ? 'done' : ''}`}
              style={{
                left: c.pos_x,
                top: c.pos_y,
                width: c.width,
                minHeight: c.height,
              }}
              onMouseDown={(e) => startDrag(e, c)}
              onContextMenu={(e) => openMenu(e, c.id)}
            >
              {(c.from_display_name || c.to_display_name) && (
                <div
                  className="card-actors"
                  style={{
                    fontSize: 10,
                    color: '#444',
                    padding: '2px 6px',
                    background: 'rgba(0,0,0,0.06)',
                    borderRadius: 3,
                    marginBottom: 4,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 4,
                    overflow: 'hidden',
                    whiteSpace: 'nowrap',
                    textOverflow: 'ellipsis',
                  }}
                >
                  <span title={c.from_actor_id}>
                    {actorIcon(c.from_actor_type)} {c.from_display_name || '?'}
                  </span>
                  <span style={{ color: '#888' }}>→</span>
                  <span title={c.to_actor_id}>
                    {actorIcon(c.to_actor_type)} {c.to_display_name || '?'}
                  </span>
                  {c.type === 'instruction' && c.state && (
                    <span
                      style={{
                        marginLeft: 'auto',
                        padding: '0 5px',
                        background: STATE_COLOR[c.state] || '#999',
                        color: '#fff',
                        borderRadius: 8,
                        fontSize: 9,
                        fontWeight: 600,
                      }}
                    >
                      {STATE_LABEL[c.state] || c.state}
                    </span>
                  )}
                </div>
              )}
              <div className="head">
                {c.card_type === 'todo' && (
                  <div
                    className="check"
                    data-no-drag
                    onClick={() => toggleDone(c)}
                  >
                    {c.is_completed ? '✓' : ''}
                  </div>
                )}
                {isEditingTitle ? (
                  <input
                    className="card-edit-overlay"
                    data-no-drag
                    autoFocus
                    value={editing.value}
                    onChange={(e) =>
                      setEditing({ ...editing, value: e.target.value })
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') commitEdit();
                      if (e.key === 'Escape') cancelEdit();
                    }}
                    onBlur={commitEdit}
                    style={{
                      flex: 1,
                      border: '1px solid #999',
                      borderRadius: 4,
                      padding: '2px 6px',
                      font: 'inherit',
                      fontWeight: 600,
                    }}
                  />
                ) : (
                  <div
                    className="ttl"
                    onDoubleClick={(e) => {
                      e.stopPropagation();
                      startEdit(c, 'title');
                    }}
                  >
                    {c.title || '(無題)'}
                  </div>
                )}
              </div>

              {isEditingBody ? (
                <textarea
                  className="card-edit-overlay"
                  data-no-drag
                  autoFocus
                  value={editing.value}
                  onChange={(e) =>
                    setEditing({ ...editing, value: e.target.value })
                  }
                  onKeyDown={(e) => {
                    if (e.key === 'Escape') cancelEdit();
                  }}
                  onBlur={commitEdit}
                  style={{
                    width: '100%',
                    minHeight: 60,
                    border: '1px solid #999',
                    borderRadius: 4,
                    padding: '4px 6px',
                    font: 'inherit',
                    marginTop: 6,
                    resize: 'vertical',
                  }}
                />
              ) : (
                <div
                  className="body"
                  onDoubleClick={(e) => {
                    e.stopPropagation();
                    startEdit(c, 'body');
                  }}
                >
                  {c.body || <span style={{ opacity: 0.4 }}>（本文）</span>}
                </div>
              )}

              <div className="foot">
                <span>{fmt(c.created_at)}</span>
                {c.trigger_condition && (
                  <span title="再開トリガー">🔔 {c.trigger_condition}</span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating Action Button: 新規カード追加 (AIサイドバーがある場合は左にオフセット) */}
      {fabOpen && fabMode === 'default' && (
        <div
          className="add-card-fab-menu"
          onMouseDown={(e) => e.stopPropagation()}
          style={{ right: 280, zIndex: 100 }}
        >
          <div className="color-row">
            {COLORS.map((col) => (
              <span
                key={col}
                title={col}
                style={{ background: COLOR_HEX[col] }}
                onClick={() => addCardViaFab({ color: col })}
              />
            ))}
          </div>
          <button className="type-btn" onClick={() => addCardViaFab({ card_type: 'idea' })}>
            💡 アイデアカード
          </button>
          <button className="type-btn" onClick={() => addCardViaFab({ card_type: 'todo' })}>
            ☐ TODOカード
          </button>
          <button
            className="type-btn"
            onClick={() => setFabMode('instruction')}
            style={{ background: '#1E2761', color: 'white' }}
          >
            📋 指示書カード
          </button>
        </div>
      )}
      {fabOpen && fabMode === 'instruction' && (
        <div
          className="add-card-fab-menu"
          onMouseDown={(e) => e.stopPropagation()}
          style={{ minWidth: 240, right: 280, zIndex: 100 }}
        >
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 4, color: '#1E2761' }}>
            📋 指示書を作成
          </div>
          <div style={{ fontSize: 10, color: '#666', marginBottom: 6 }}>
            差出人 → 宛先 を選択
          </div>
          <select
            value={instForm.from}
            onChange={(e) => setInstForm({ ...instForm, from: e.target.value })}
            style={{ width: '100%', padding: '4px 6px', fontSize: 12, marginBottom: 4 }}
          >
            <option value="">差出人を選択...</option>
            {actors
              .filter((a) => a.actor_type === 'human')
              .map((a) => (
                <option key={a.actor_id} value={a.actor_id}>
                  👤 {a.display_name} ({a.actor_id})
                </option>
              ))}
          </select>
          <div style={{ textAlign: 'center', color: '#888', fontSize: 14, lineHeight: 1 }}>↓</div>
          <select
            value={instForm.to}
            onChange={(e) => setInstForm({ ...instForm, to: e.target.value })}
            style={{ width: '100%', padding: '4px 6px', fontSize: 12, marginTop: 4, marginBottom: 6 }}
          >
            <option value="">宛先を選択...</option>
            {actors
              .filter((a) => a.actor_type === 'ai')
              .map((a) => (
                <option key={a.actor_id} value={a.actor_id}>
                  🤖 {a.display_name} ({a.actor_id})
                </option>
              ))}
          </select>
          <input
            type="text"
            placeholder="件名 (省略可)"
            value={instForm.subject}
            onChange={(e) => setInstForm({ ...instForm, subject: e.target.value })}
            style={{ width: '100%', padding: '4px 6px', fontSize: 12, marginBottom: 6 }}
          />
          <button
            className="type-btn"
            onClick={createInstructionViaFab}
            style={{ background: '#F96167', color: 'white', fontWeight: 700 }}
          >
            ✓ 作成
          </button>
          <button
            className="type-btn"
            onClick={() => setFabMode('default')}
            style={{ fontSize: 11 }}
          >
            ← 戻る
          </button>
        </div>
      )}
      <button
        className="add-card-fab"
        style={{ right: 280, zIndex: 100 }}
        onClick={() => {
          if (fabOpen) {
            setFabOpen(false);
            setFabMode('default');
          } else {
            setFabOpen(true);
          }
        }}
        title="新規カード"
      >
        {fabOpen ? '×' : '＋'}
      </button>
      </div>

      {menu && (
        <div
          className="card-menu"
          style={{ left: menu.x, top: menu.y, position: 'fixed' }}
          onMouseDown={(e) => e.stopPropagation()}
        >
          <div className="color-swatches">
            {COLORS.map((col) => (
              <span
                key={col}
                style={{ background: COLOR_HEX[col] }}
                onClick={() => changeColor(menu.cardId, col)}
              />
            ))}
          </div>
          <button onClick={() => cardToTask(menu.cardId)}>→タスク化</button>
          <button onClick={() => toggleType(menu.cardId)}>
            TODO/アイデア切替
          </button>
          <button onClick={() => deleteCard(menu.cardId)}>削除</button>
        </div>
      )}

      {/* v0.1: AIサイドバー (ドラッグ&ドロップで割り当て) */}
      {actors.filter((a) => a.actor_type === 'ai').length > 0 && (
        <div
          className="ai-dispatch-sidebar"
          style={{
            position: 'fixed',
            top: 100,
            right: 0,
            bottom: 0,
            width: 260,
            background: '#fafafa',
            borderLeft: '2px solid #1E2761',
            padding: 12,
            overflowY: 'auto',
            zIndex: 50,
            boxShadow: '-2px 0 8px rgba(0,0,0,0.05)',
            fontSize: 12,
          }}
        >
          <div
            style={{
              fontWeight: 700,
              fontSize: 13,
              color: '#1E2761',
              marginBottom: 4,
            }}
          >
            📊 AI 担当タスク
          </div>
          <div style={{ fontSize: 10, color: '#888', marginBottom: 10 }}>
            付箋をドラッグ&ドロップで割当
          </div>
          {actors
            .filter((a) => a.actor_type === 'ai')
            .map((ai) => {
              const myCards = cards.filter((c) => c.to_actor_id === ai.actor_id);
              const active = myCards.filter((c) =>
                ['waiting', 'in_progress', 'overdue', 'decision_required'].includes(
                  c.state
                )
              );
              return (
                <div
                  key={ai.actor_id}
                  data-ai-target={ai.actor_id}
                  style={{
                    background: '#fff',
                    border: '1px dashed #bbb',
                    borderRadius: 6,
                    padding: 8,
                    marginBottom: 10,
                    minHeight: 80,
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      marginBottom: 6,
                      paddingBottom: 4,
                      borderBottom: '1px solid #eee',
                    }}
                  >
                    <span style={{ fontWeight: 700, fontSize: 12 }}>
                      🤖 {ai.display_name}
                    </span>
                    <span
                      style={{
                        background: active.length > 0 ? '#F96167' : '#999',
                        color: '#fff',
                        borderRadius: 10,
                        padding: '1px 7px',
                        fontSize: 10,
                        fontWeight: 700,
                      }}
                    >
                      {active.length}
                    </span>
                  </div>
                  {myCards.length === 0 ? (
                    <div
                      style={{
                        fontSize: 10,
                        color: '#bbb',
                        textAlign: 'center',
                        padding: '14px 4px',
                      }}
                    >
                      ↓ 付箋をここにドロップ ↓
                    </div>
                  ) : (
                    myCards.map((c) => (
                      <div
                        key={c.id}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 4,
                          padding: '3px 4px',
                          fontSize: 11,
                          borderBottom: '1px dotted #eee',
                        }}
                      >
                        <span
                          style={{
                            width: 7,
                            height: 7,
                            borderRadius: '50%',
                            background: STATE_COLOR[c.state] || '#999',
                            flexShrink: 0,
                          }}
                          title={STATE_LABEL[c.state] || c.state}
                        />
                        <span
                          style={{
                            flex: 1,
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}
                          title={c.subject || c.title}
                        >
                          {c.subject || c.title || '(無題)'}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              );
            })}
        </div>
      )}
    </div>
  );
}

function fmt(iso) {
  if (!iso) return '';
  return iso.slice(5, 10).replace('-', '/');
}
