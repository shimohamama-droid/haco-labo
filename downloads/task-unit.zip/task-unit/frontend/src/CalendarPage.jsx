import React, { useEffect, useMemo, useState } from 'react';
import { api } from './api.js';

const DOW = ['日', '月', '火', '水', '木', '金', '土'];

const STATE_COLOR = {
  waiting: '#9E9E9E',
  in_progress: '#2196F3',
  completed: '#4CAF50',
  decision_required: '#FF9800',
  overdue: '#F44336',
  abandoned: '#666',
};

function fmtMonth(d) {
  return `${d.getFullYear()}年${d.getMonth() + 1}月`;
}
function isoDate(d) {
  // ローカル日付の YYYY-MM-DD (タイムゾーンずれを防ぐ)
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function todayIso() {
  return isoDate(new Date());
}

export default function CalendarPage() {
  const [current, setCurrent] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const [tasks, setTasks] = useState([]);
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(null);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const t = await api.listTasks('all');
        setTasks(t);
        const boards = await api.listBoards();
        const all = [];
        for (const b of boards) {
          const bc = await api.listCards(b.id);
          bc.forEach((c) => all.push({ ...c, _board_name: b.name }));
        }
        setCards(all);
      } catch (e) {
        console.error('calendar load failed', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // 日付別グルーピング
  const itemsByDate = useMemo(() => {
    const map = {};
    tasks.forEach((t) => {
      if (!t.scheduled_date) return;
      const d = t.scheduled_date.slice(0, 10);
      if (!map[d]) map[d] = { tasks: [], deadlines: [] };
      map[d].tasks.push(t);
    });
    cards.forEach((c) => {
      if (!c.deadline) return;
      const d = c.deadline.slice(0, 10);
      if (!map[d]) map[d] = { tasks: [], deadlines: [] };
      map[d].deadlines.push(c);
    });
    return map;
  }, [tasks, cards]);

  // 月グリッド (6週 × 7日)
  const grid = useMemo(() => {
    const year = current.getFullYear();
    const month = current.getMonth();
    const startWeekday = new Date(year, month, 1).getDay();
    const rows = [];
    let day = 1 - startWeekday;
    for (let w = 0; w < 6; w++) {
      const row = [];
      for (let dow = 0; dow < 7; dow++) {
        const date = new Date(year, month, day);
        row.push({
          date,
          inMonth: date.getMonth() === month,
          iso: isoDate(date),
          dow,
        });
        day++;
      }
      rows.push(row);
    }
    return rows;
  }, [current]);

  const TODAY_ISO = todayIso();

  function gotoPrev() {
    setCurrent(new Date(current.getFullYear(), current.getMonth() - 1, 1));
    setSelectedDate(null);
  }
  function gotoNext() {
    setCurrent(new Date(current.getFullYear(), current.getMonth() + 1, 1));
    setSelectedDate(null);
  }
  function gotoToday() {
    const d = new Date();
    setCurrent(new Date(d.getFullYear(), d.getMonth(), 1));
    setSelectedDate(todayIso());
  }

  const selectedItems = selectedDate ? itemsByDate[selectedDate] : null;

  return (
    <div style={{ padding: 16, maxWidth: 1200, margin: '0 auto' }}>
      {/* ヘッダー */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          marginBottom: 16,
        }}
      >
        <button onClick={gotoPrev} style={btnStyle()}>
          ← 前月
        </button>
        <h2 style={{ flex: 1, textAlign: 'center', margin: 0, color: '#1E2761' }}>
          📆 {fmtMonth(current)}
        </h2>
        <button onClick={gotoNext} style={btnStyle()}>
          次月 →
        </button>
        <button onClick={gotoToday} style={btnStyle('accent')}>
          今日
        </button>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: 40, color: '#888' }}>
          読み込み中…
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16 }}>
          {/* 月グリッド */}
          <div>
            {/* 曜日ヘッダー */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(7, 1fr)',
                gap: 1,
                marginBottom: 1,
              }}
            >
              {DOW.map((d, i) => (
                <div
                  key={i}
                  style={{
                    padding: '6px 4px',
                    background: '#1E2761',
                    color: '#fff',
                    textAlign: 'center',
                    fontSize: 12,
                    fontWeight: 700,
                  }}
                >
                  {d}
                </div>
              ))}
            </div>

            {/* 週ごとの行 */}
            {grid.map((week, wi) => (
              <div
                key={wi}
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(7, 1fr)',
                  gap: 1,
                }}
              >
                {week.map((cell) => {
                  const items = itemsByDate[cell.iso];
                  const isToday = cell.iso === TODAY_ISO;
                  const isSelected = cell.iso === selectedDate;
                  return (
                    <div
                      key={cell.iso}
                      onClick={() =>
                        setSelectedDate(isSelected ? null : cell.iso)
                      }
                      style={{
                        minHeight: 90,
                        background: cell.inMonth ? '#fff' : '#f6f6f6',
                        opacity: cell.inMonth ? 1 : 0.5,
                        border: isSelected
                          ? '2px solid #F96167'
                          : isToday
                          ? '2px solid #1E2761'
                          : '1px solid #ddd',
                        padding: 4,
                        cursor: 'pointer',
                        position: 'relative',
                      }}
                    >
                      <div
                        style={{
                          fontSize: 12,
                          fontWeight: isToday ? 700 : 500,
                          color:
                            cell.dow === 0
                              ? '#F96167'
                              : cell.dow === 6
                              ? '#2196F3'
                              : '#333',
                        }}
                      >
                        {cell.date.getDate()}
                      </div>
                      {items && (
                        <div style={{ marginTop: 4 }}>
                          {items.tasks.length > 0 && (
                            <div
                              style={{
                                fontSize: 10,
                                background: '#E8F5E9',
                                color: '#2E7D32',
                                padding: '1px 5px',
                                borderRadius: 8,
                                marginBottom: 2,
                                display: 'inline-block',
                              }}
                            >
                              📝 {items.tasks.length} タスク
                            </div>
                          )}
                          {items.deadlines.length > 0 && (
                            <div
                              style={{
                                fontSize: 10,
                                background: '#FFF3E0',
                                color: '#E65100',
                                padding: '1px 5px',
                                borderRadius: 8,
                                display: 'inline-block',
                              }}
                            >
                              ⏰ {items.deadlines.length} 期限
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}

            {/* 凡例 */}
            <div
              style={{
                marginTop: 12,
                fontSize: 11,
                color: '#666',
                display: 'flex',
                gap: 16,
              }}
            >
              <span>📝 タスク(scheduled_date)</span>
              <span>⏰ 指示書の期限(deadline)</span>
              <span style={{ color: '#1E2761' }}>━━ 今日</span>
              <span style={{ color: '#F96167' }}>━━ 選択日</span>
            </div>
          </div>

          {/* 右サイドパネル: 選択日の詳細 */}
          <div
            style={{
              background: '#fafafa',
              border: '1px solid #ddd',
              borderRadius: 6,
              padding: 12,
              maxHeight: 600,
              overflowY: 'auto',
            }}
          >
            {!selectedDate ? (
              <div style={{ color: '#888', fontSize: 13, textAlign: 'center', padding: 30 }}>
                ← 日付をクリックすると詳細が出ます
              </div>
            ) : (
              <>
                <div
                  style={{
                    fontSize: 16,
                    fontWeight: 700,
                    color: '#1E2761',
                    borderBottom: '2px solid #1E2761',
                    paddingBottom: 6,
                    marginBottom: 10,
                  }}
                >
                  📆 {selectedDate}
                </div>

                {!selectedItems && (
                  <div style={{ color: '#999', fontSize: 13 }}>
                    この日には予定がありません。
                  </div>
                )}

                {selectedItems?.tasks?.length > 0 && (
                  <div style={{ marginBottom: 14 }}>
                    <div
                      style={{
                        fontSize: 13,
                        fontWeight: 700,
                        color: '#2E7D32',
                        marginBottom: 6,
                      }}
                    >
                      📝 タスク ({selectedItems.tasks.length})
                    </div>
                    {selectedItems.tasks.map((t) => (
                      <div
                        key={t.id}
                        style={{
                          background: '#fff',
                          border: '1px solid #c8e6c9',
                          borderRadius: 4,
                          padding: '6px 8px',
                          fontSize: 12,
                          marginBottom: 4,
                          display: 'flex',
                          alignItems: 'center',
                          gap: 6,
                        }}
                      >
                        <span
                          style={{
                            width: 7,
                            height: 7,
                            borderRadius: '50%',
                            background:
                              t.status === 'done' ? '#4CAF50' : '#FFC107',
                          }}
                        />
                        <span style={{ flex: 1 }}>{t.title}</span>
                        {t.estimated_minutes && (
                          <span style={{ color: '#666', fontSize: 10 }}>
                            ⏱ {t.estimated_minutes}分
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {selectedItems?.deadlines?.length > 0 && (
                  <div>
                    <div
                      style={{
                        fontSize: 13,
                        fontWeight: 700,
                        color: '#E65100',
                        marginBottom: 6,
                      }}
                    >
                      ⏰ 期限のある指示書 ({selectedItems.deadlines.length})
                    </div>
                    {selectedItems.deadlines.map((c) => (
                      <div
                        key={c.id}
                        style={{
                          background: '#fff',
                          border: '1px solid #ffe0b2',
                          borderRadius: 4,
                          padding: '6px 8px',
                          fontSize: 12,
                          marginBottom: 4,
                        }}
                      >
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 4,
                            marginBottom: 2,
                          }}
                        >
                          <span
                            style={{
                              width: 7,
                              height: 7,
                              borderRadius: '50%',
                              background: STATE_COLOR[c.state] || '#999',
                            }}
                          />
                          <span style={{ fontWeight: 600, flex: 1 }}>
                            {c.subject || c.title || '(無題)'}
                          </span>
                        </div>
                        <div style={{ fontSize: 10, color: '#888' }}>
                          {c.from_display_name && c.to_display_name && (
                            <>
                              {c.from_display_name} → {c.to_display_name}・
                            </>
                          )}
                          {c._board_name}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function btnStyle(variant) {
  const base = {
    border: '1px solid #ccc',
    background: '#fff',
    padding: '6px 14px',
    borderRadius: 4,
    cursor: 'pointer',
    fontSize: 12,
  };
  if (variant === 'accent') {
    return { ...base, background: '#1E2761', color: '#fff', border: 'none' };
  }
  return base;
}
