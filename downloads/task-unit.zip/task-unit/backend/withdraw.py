"""HACO スタッフルーム 撤収スクリプト (Task #13)

claude-code から呼ばれて、全データを指定ディレクトリにエクスポートする。
ベンダーロックインなしの実装。CLAUDE.md の撤収機能仕様に準拠。

実行:
    cd ~/Desktop/claude/task-unit
    backend/.venv/bin/python backend/withdraw.py <出力先ディレクトリ>

例:
    backend/.venv/bin/python backend/withdraw.py ~/Desktop/haco_withdraw

出力構造:
    output_dir/
    ├── data/
    │   ├── cards.json / cards.csv
    │   ├── card_history.json / card_history.csv
    │   ├── actors.json / actors.csv
    │   ├── attachments.json
    │   ├── boards.json
    │   ├── tasks.json
    │   └── notes.json
    ├── reports/
    │   └── summary.pdf
    ├── disconnect_guide.md
    └── withdraw_certificate.pdf
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

# 日本語フォント (CID, ファイル不要)
pdfmetrics.registerFont(UnicodeCIDFont("HeiseiKakuGo-W5"))
JP_FONT = "HeiseiKakuGo-W5"

DB_PATH_DEFAULT = Path(__file__).parent / "task_unit.db"


# ---------- DB 読み込み ----------
def fetch_all(db_path: Path):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    tables = ["cards", "card_history", "actors", "attachments", "boards", "tasks", "notes", "reviews"]
    result = {}
    for t in tables:
        try:
            rows = conn.execute(f"SELECT * FROM {t}").fetchall()
            result[t] = [dict(r) for r in rows]
        except sqlite3.OperationalError:
            result[t] = []
    conn.close()
    return result


# ---------- JSON / CSV 出力 ----------
def dump_json(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2, default=str)


def dump_csv(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            row_out = {k: (str(v) if v is not None else "") for k, v in r.items()}
            w.writerow(row_out)


# ---------- 集計 ----------
def compute_stats(data):
    cards = data["cards"]
    history = data["card_history"]
    actors = data["actors"]

    by_state = {}
    by_type = {}
    by_to_actor_type = {}
    for c in cards:
        s = c.get("state") or "unknown"
        by_state[s] = by_state.get(s, 0) + 1
        t = c.get("type") or "idea"
        by_type[t] = by_type.get(t, 0) + 1
        ta = c.get("to_actor_type") or "n/a"
        by_to_actor_type[ta] = by_to_actor_type.get(ta, 0) + 1

    completed_by_ai = sum(
        1 for c in cards
        if c.get("state") == "completed" and c.get("to_actor_type") == "ai"
    )
    completed_by_human = sum(
        1 for c in cards
        if c.get("state") == "completed" and c.get("to_actor_type") == "human"
    )

    actions_count = {}
    for h in history:
        a = h.get("action") or "unknown"
        actions_count[a] = actions_count.get(a, 0) + 1

    return {
        "total_cards": len(cards),
        "total_history": len(history),
        "total_actors": len(actors),
        "by_state": by_state,
        "by_type": by_type,
        "by_to_actor_type": by_to_actor_type,
        "completed_by_ai": completed_by_ai,
        "completed_by_human": completed_by_human,
        "actions_count": actions_count,
    }


# ---------- PDF: 総括レポート ----------
def jp_style(name="JP", size=10, leading=14, color=colors.black):
    return ParagraphStyle(
        name=name, fontName=JP_FONT, fontSize=size, leading=leading,
        textColor=color,
    )


def make_summary_pdf(path: Path, data, stats, generated_at: datetime):
    path.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(path),
        pagesize=A4,
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=20 * mm, bottomMargin=20 * mm,
        title="HACO スタッフルーム 撤収総括レポート",
    )
    story = []
    title = jp_style(size=20, leading=28, color=colors.HexColor("#1E2761"))
    h2 = jp_style(size=14, leading=20, color=colors.HexColor("#1E2761"))
    body = jp_style(size=10, leading=16)
    small = jp_style(size=8, leading=12, color=colors.grey)

    # 表紙
    story.append(Paragraph("HACO スタッフルーム 撤収総括レポート", title))
    story.append(Spacer(1, 8 * mm))
    story.append(Paragraph(f"発行日時: {generated_at.isoformat(timespec='seconds')}", body))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(
        "本レポートは HACO スタッフルームから撤収する際に発行される、"
        "期間中の業務処理実績の集計です。", body))
    story.append(Spacer(1, 10 * mm))

    # 1. データ規模
    story.append(Paragraph("1. データ規模", h2))
    story.append(Spacer(1, 3 * mm))
    table_data = [
        ["項目", "件数"],
        ["カード(全種類)", stats["total_cards"]],
        ["履歴エントリ", stats["total_history"]],
        ["登録 actor", stats["total_actors"]],
    ]
    table = Table(table_data, colWidths=[80 * mm, 40 * mm])
    table.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, -1), JP_FONT, 10),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E2761")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (1, 1), (1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor("#F2F2F2")),
    ]))
    story.append(table)
    story.append(Spacer(1, 8 * mm))

    # 2. 状態別
    story.append(Paragraph("2. カード状態の分布", h2))
    story.append(Spacer(1, 3 * mm))
    state_rows = [["状態", "件数"]]
    for s, n in sorted(stats["by_state"].items(), key=lambda x: -x[1]):
        state_rows.append([s, n])
    t2 = Table(state_rows, colWidths=[80 * mm, 40 * mm])
    t2.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, -1), JP_FONT, 10),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E2761")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (1, 1), (1, -1), "RIGHT"),
    ]))
    story.append(t2)
    story.append(Spacer(1, 8 * mm))

    # 3. AI vs 人間処理
    story.append(Paragraph("3. 完了タスクの処理者内訳", h2))
    story.append(Spacer(1, 3 * mm))
    ai = stats["completed_by_ai"]
    hu = stats["completed_by_human"]
    total = ai + hu
    pct_ai = (ai / total * 100) if total else 0
    pct_hu = (hu / total * 100) if total else 0
    proc_rows = [
        ["処理者", "件数", "割合"],
        ["AI", ai, f"{pct_ai:.1f}%"],
        ["人間", hu, f"{pct_hu:.1f}%"],
        ["合計", total, "100.0%"],
    ]
    t3 = Table(proc_rows, colWidths=[60 * mm, 40 * mm, 30 * mm])
    t3.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, -1), JP_FONT, 10),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E2761")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#CADCFC")),
        ("FONT", (0, -1), (-1, -1), JP_FONT, 10),
    ]))
    story.append(t3)
    story.append(Spacer(1, 8 * mm))

    # 4. アクション内訳
    story.append(Paragraph("4. 履歴アクション内訳", h2))
    story.append(Spacer(1, 3 * mm))
    act_rows = [["アクション", "件数"]]
    for a, n in sorted(stats["actions_count"].items(), key=lambda x: -x[1])[:20]:
        act_rows.append([a, n])
    t4 = Table(act_rows, colWidths=[80 * mm, 40 * mm])
    t4.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, -1), JP_FONT, 10),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E2761")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (1, 1), (1, -1), "RIGHT"),
    ]))
    story.append(t4)
    story.append(PageBreak())

    # 5. 撤収について
    story.append(Paragraph("5. 撤収後のデータ取り扱い", h2))
    story.append(Spacer(1, 3 * mm))
    story.append(Paragraph(
        "本撤収パッケージには、上記すべてのデータが JSON / CSV 形式で含まれています。"
        "再利用・他システムへの移行・社内アーカイブにご活用ください。", body))
    story.append(Spacer(1, 5 * mm))
    story.append(Paragraph(
        "撤収完了証明書 (withdraw_certificate.pdf) に各ファイルの SHA-256 チェックサムを"
        "記載しています。データの完全性検証に使用できます。", body))
    story.append(Spacer(1, 5 * mm))
    story.append(Paragraph(
        "外部サービスとの接続(Cloudflare/Notion等)の削除手順は同梱の disconnect_guide.md "
        "を参照してください。", body))
    story.append(Spacer(1, 15 * mm))
    story.append(Paragraph("© AKOAKO STUDIO / HACO LABO", small))
    doc.build(story)


# ---------- Markdown: 接続解除ガイド ----------
def make_disconnect_guide(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    md = """# HACO スタッフルーム 外部接続 削除手順書

撤収にあたり、外部サービスとの接続を削除する手順をまとめたものです。
御社の運用環境に応じて該当する項目だけ実施してください。

## 1. Cloudflare Workers (該当する場合)

1. Cloudflare ダッシュボードにログイン
2. Workers & Pages → 該当ワーカー(例: task-unit)
3. 「設定」→「削除」を実行
4. D1 データベース → 該当DB → 「削除」
5. KV / R2 を利用している場合は同様に削除

```bash
# CLI で実施する場合
wrangler delete <worker_name>
wrangler d1 delete <database_name>
```

## 2. Notion (該当する場合)

1. Notion で該当データベース/ページを開く
2. 「...」メニュー → 「削除」
3. 「ゴミ箱」からも完全削除
4. インテグレーションの撤去: 設定 → コネクト → HACO関連を全削除

## 3. Slack / Teams 連携 (該当する場合)

1. ワークスペース管理画面 → アプリ
2. HACO関連のアプリを「削除」または「アンインストール」
3. Webhook URLが残っている場合は無効化

## 4. ローカル環境

```bash
# データベース
rm -f backend/task_unit.db
rm -f backend/task_unit.db.bak.*

# Python 仮想環境
rm -rf backend/.venv

# Node modules
rm -rf frontend/node_modules
rm -rf worker/node_modules

# 環境変数ファイル
rm -f backend/.env
rm -f frontend/.env.production
```

## 5. claude-code 設定

```bash
# claude-code が読んでいる CLAUDE.md やプロジェクト指示が
# 別フォルダにある場合は手動削除
```

## 6. APIキー類の無効化

以下のキーを発行している場合、各プロバイダー管理画面で無効化:

- Anthropic API キー (https://console.anthropic.com)
- Cloudflare API トークン
- Slack Bot Token
- その他

## 7. 物理アーカイブ (任意)

撤収パッケージ全体(本ディレクトリ)を:

- 暗号化 ZIP にして社内ファイルサーバーへ
- バックアップメディアに保管
- クラウドストレージ (社内承認済みのもの) へ

保管期間は監査要件に応じて決定してください。
HACOデフォルト推奨: 12ヶ月。

## 8. 確認チェックリスト

- [ ] 外部サービス(Cloudflare/Notion等)からの完全削除
- [ ] APIキーの無効化
- [ ] ローカルDB・環境変数の削除
- [ ] 撤収パッケージのアーカイブ完了
- [ ] 関係者への撤収完了通知

---

不明点は akoako@akoakostudio.com までご連絡ください。
本ガイドはあくまで一般的な手順です。御社の運用環境に応じて適宜調整してください。
"""
    path.write_text(md, encoding="utf-8")


# ---------- PDF: 撤収完了証明書 ----------
def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def make_certificate_pdf(path: Path, out_dir: Path, stats, generated_at):
    path.parent.mkdir(parents=True, exist_ok=True)

    # 出力ディレクトリ内の全ファイルのチェックサム(自分自身は除く)
    file_hashes = []
    for p in sorted(out_dir.rglob("*")):
        if p.is_file() and p.resolve() != path.resolve():
            rel = p.relative_to(out_dir)
            file_hashes.append((str(rel), p.stat().st_size, file_sha256(p)))

    doc = SimpleDocTemplate(
        str(path),
        pagesize=A4,
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=20 * mm, bottomMargin=20 * mm,
        title="HACO スタッフルーム 撤収完了証明書",
    )
    story = []

    title = jp_style(size=22, leading=32, color=colors.HexColor("#1E2761"))
    h2 = jp_style(size=14, leading=20, color=colors.HexColor("#1E2761"))
    body = jp_style(size=10, leading=16)
    small = jp_style(size=8, leading=12, color=colors.grey)
    mono = ParagraphStyle(
        name="mono", fontName="Courier", fontSize=7, leading=10,
        textColor=colors.black,
    )

    story.append(Paragraph("撤収完了証明書", title))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("Certificate of Withdrawal", jp_style(size=10, color=colors.grey)))
    story.append(Spacer(1, 10 * mm))

    story.append(Paragraph(
        "本書は、HACO スタッフルームからのデータ撤収が完了したことを証明するものです。",
        body))
    story.append(Spacer(1, 10 * mm))

    # 撤収サマリー
    story.append(Paragraph("撤収サマリー", h2))
    story.append(Spacer(1, 3 * mm))
    summary_rows = [
        ["項目", "内容"],
        ["撤収日時", generated_at.isoformat(timespec="seconds")],
        ["撤収対象 カード", f"{stats['total_cards']:,} 件"],
        ["撤収対象 履歴", f"{stats['total_history']:,} 件"],
        ["撤収対象 actor", f"{stats['total_actors']:,} 件"],
        ["出力ファイル数", f"{len(file_hashes):,} 件"],
        ["HACO スタッフルームバージョン", "v0.1"],
    ]
    t = Table(summary_rows, colWidths=[70 * mm, 90 * mm])
    t.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, -1), JP_FONT, 10),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E2761")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor("#F2F2F2")),
    ]))
    story.append(t)
    story.append(Spacer(1, 10 * mm))

    # チェックサム
    story.append(Paragraph("チェックサム (SHA-256)", h2))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph(
        "以下は撤収パッケージに含まれる全ファイルの SHA-256 ハッシュです。"
        "受領後の改ざん検証にお使いください。", body))
    story.append(Spacer(1, 3 * mm))

    hash_rows = [["ファイル", "サイズ(bytes)", "SHA-256"]]
    for rel, size, h in file_hashes:
        # ハッシュは長いので先頭16文字…後ろ8文字で表示(全長は別行)
        hash_rows.append([rel, f"{size:,}", h])
    t2 = Table(hash_rows, colWidths=[60 * mm, 25 * mm, 80 * mm])
    t2.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, 0), JP_FONT, 9),
        ("FONT", (0, 1), (-1, -1), "Courier", 6),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E2761")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 1), (1, -1), "RIGHT"),
    ]))
    story.append(t2)
    story.append(Spacer(1, 10 * mm))

    # フッター
    story.append(Spacer(1, 5 * mm))
    story.append(Paragraph(
        "本証明書は HACO スタッフルーム 撤収機能 (claude --withdraw) "
        "によって自動発行されました。", small))
    story.append(Paragraph(
        "発行元: AKOAKO STUDIO / HACO LABO  (https://akoakostudio.com)", small))
    doc.build(story)


# ---------- CLI ----------
def main():
    if len(sys.argv) < 2:
        print("Usage: python withdraw.py <出力先ディレクトリ> [--db <パス>]")
        sys.exit(1)
    out_dir = Path(sys.argv[1]).expanduser().resolve()
    db_path = DB_PATH_DEFAULT
    if "--db" in sys.argv:
        idx = sys.argv.index("--db")
        db_path = Path(sys.argv[idx + 1]).expanduser().resolve()
    if not db_path.exists():
        print(f"❌ DBファイルが見つかりません: {db_path}")
        sys.exit(1)

    out_dir.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone.utc)

    print(f"📦 撤収開始: {out_dir}")
    print(f"📂 DB: {db_path}")

    # 1. データ読み込み
    print("\n[1/5] データ読み込み中...")
    data = fetch_all(db_path)
    for t, rows in data.items():
        print(f"  {t}: {len(rows)} 件")

    # 2. JSON / CSV エクスポート
    print("\n[2/5] JSON / CSV エクスポート中...")
    data_dir = out_dir / "data"
    for t, rows in data.items():
        dump_json(data_dir / f"{t}.json", rows)
        dump_csv(data_dir / f"{t}.csv", rows)
    print(f"  → {data_dir}")

    # 3. 集計
    print("\n[3/5] 集計中...")
    stats = compute_stats(data)
    dump_json(out_dir / "data" / "_stats.json", [stats])

    # 4. PDF: 総括レポート
    print("\n[4/5] PDF レポート生成中...")
    summary_pdf = out_dir / "reports" / "summary.pdf"
    make_summary_pdf(summary_pdf, data, stats, now)
    print(f"  → {summary_pdf}")

    # 5. 接続解除ガイド + 証明書
    print("\n[5/5] 接続解除ガイド & 証明書生成中...")
    disconnect_md = out_dir / "disconnect_guide.md"
    make_disconnect_guide(disconnect_md)
    print(f"  → {disconnect_md}")

    cert_pdf = out_dir / "withdraw_certificate.pdf"
    make_certificate_pdf(cert_pdf, out_dir, stats, now)
    print(f"  → {cert_pdf}")

    print(f"\n✅ 撤収完了: {out_dir}")
    print(f"   カード: {stats['total_cards']} 件 / 履歴: {stats['total_history']} 件 / actor: {stats['total_actors']} 件")
    print(f"   AI処理: {stats['completed_by_ai']} 件 / 人間処理: {stats['completed_by_human']} 件")


if __name__ == "__main__":
    main()
