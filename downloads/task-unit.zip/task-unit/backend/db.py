import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path

DB_PATH = os.environ.get("DB_PATH", str(Path(__file__).parent / "task_unit.db"))


def init_db():
    with get_conn() as conn:
        c = conn.cursor()
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS tasks (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              title TEXT NOT NULL,
              description TEXT,
              category TEXT,
              type_tag TEXT,
              estimated_minutes INTEGER,
              actual_minutes INTEGER,
              progress INTEGER DEFAULT 0,
              status TEXT DEFAULT 'todo',
              scheduled_date DATE,
              completed_at DATETIME,
              source_card_id INTEGER,
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS reviews (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              review_date DATE,
              total_minutes INTEGER,
              completed_count INTEGER,
              notes TEXT,
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS notes (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              title TEXT,
              body TEXT,
              tags TEXT,
              category TEXT,
              linked_task_id INTEGER,
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
              updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS boards (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              display_order INTEGER DEFAULT 0,
              is_system INTEGER DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS cards (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              board_id INTEGER NOT NULL,
              card_type TEXT DEFAULT 'idea',
              title TEXT,
              body TEXT,
              color TEXT DEFAULT 'yellow',
              pos_x INTEGER DEFAULT 0,
              pos_y INTEGER DEFAULT 0,
              width INTEGER DEFAULT 200,
              height INTEGER DEFAULT 120,
              is_completed INTEGER DEFAULT 0,
              trigger_condition TEXT,
              converted_to_task_id INTEGER,
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
              updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (board_id) REFERENCES boards(id)
            );

            CREATE TABLE IF NOT EXISTS predictions (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              task_id INTEGER,
              predicted_minutes INTEGER,
              actual_minutes INTEGER,
              diff_pct REAL,
              similar_tasks TEXT,
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            -- v0.1 spec: 指示書化のための追加テーブル
            CREATE TABLE IF NOT EXISTS card_history (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              card_id INTEGER NOT NULL,
              timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
              actor_type TEXT,
              actor_id TEXT,
              action TEXT,
              from_state TEXT,
              to_state TEXT,
              details TEXT,
              FOREIGN KEY (card_id) REFERENCES cards(id)
            );

            CREATE TABLE IF NOT EXISTS actors (
              actor_id TEXT PRIMARY KEY,
              actor_type TEXT NOT NULL,
              display_name TEXT NOT NULL,
              contact TEXT,
              is_active INTEGER DEFAULT 1,
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS attachments (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              card_id INTEGER NOT NULL,
              attach_type TEXT,
              value TEXT,
              label TEXT,
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (card_id) REFERENCES cards(id)
            );

            CREATE INDEX IF NOT EXISTS idx_card_history_card_id ON card_history(card_id);
            CREATE INDEX IF NOT EXISTS idx_attachments_card_id ON attachments(card_id);
            """
        )
        # seed boards if empty
        c.execute("SELECT COUNT(*) FROM boards")
        if c.fetchone()[0] == 0:
            c.executemany(
                "INSERT INTO boards (name, display_order, is_system) VALUES (?,?,?)",
                [("汎用", 0, 0), ("中断BOX", 1, 1)],
            )
            # seed initial 中断BOX cards
            c.execute("SELECT id FROM boards WHERE name='中断BOX'")
            box_id = c.fetchone()[0]
            seeds = [
                ("サンプル: 新機能の検討", "外部ツールのアップデート待ち", "pink", 40, 40, "次回リリースの発表"),
                ("サンプル: デザイン刷新", "仕様の確定後に再開", "skyblue", 280, 40, "仕様確定"),
                ("サンプル: 保留中のアイデア", "優先度が上がったら着手", "gray", 520, 40, "手持ち案件の完了"),
            ]
            c.executemany(
                """INSERT INTO cards (board_id, card_type, title, body, color, pos_x, pos_y, trigger_condition)
                   VALUES (?, 'idea', ?, ?, ?, ?, ?, ?)""",
                [(box_id, t, b, col, x, y, trig) for t, b, col, x, y, trig in seeds],
            )
        # migration: add category column to notes if missing (idempotent)
        c.execute("PRAGMA table_info(notes)")
        cols = [r[1] for r in c.fetchall()]
        if "category" not in cols:
            c.execute("ALTER TABLE notes ADD COLUMN category TEXT")

        # migration: v0.1 指示書フィールドを cards に追加 (idempotent)
        c.execute("PRAGMA table_info(cards)")
        existing_card_cols = {r[1] for r in c.fetchall()}
        new_card_cols = [
            ("uuid", "TEXT"),
            ("schema_version", "INTEGER DEFAULT 1"),
            ("type", "TEXT DEFAULT 'idea'"),
            ("from_actor_type", "TEXT"),
            ("from_actor_id", "TEXT"),
            ("from_display_name", "TEXT"),
            ("to_actor_type", "TEXT"),
            ("to_actor_id", "TEXT"),
            ("to_display_name", "TEXT"),
            ("subject", "TEXT"),
            ("deadline", "DATETIME"),
            ("urgency", "TEXT"),
            ("state", "TEXT DEFAULT 'waiting'"),
            ("handoff_what", "TEXT"),
            ("handoff_result", "TEXT"),
            ("handoff_next", "TEXT"),
            ("handoff_evidence", "TEXT"),
            ("handoff_held_for_judgment", "TEXT"),
            ("is_editable", "INTEGER DEFAULT 1"),
            ("edit_locked_reason", "TEXT"),
        ]
        for col_name, col_def in new_card_cols:
            if col_name not in existing_card_cols:
                c.execute(f"ALTER TABLE cards ADD COLUMN {col_name} {col_def}")

        # v0.1 cards 用インデックス (列追加後に作成)
        c.execute("CREATE INDEX IF NOT EXISTS idx_cards_uuid ON cards(uuid)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cards_state ON cards(state)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cards_to_actor_id ON cards(to_actor_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cards_from_actor_id ON cards(from_actor_id)")

        # backfill uuid for existing cards
        import uuid as _uuid
        c.execute("SELECT id FROM cards WHERE uuid IS NULL OR uuid = ''")
        for r in c.fetchall():
            c.execute("UPDATE cards SET uuid = ? WHERE id = ?", (str(_uuid.uuid4()), r[0]))

        # seed default actors if empty (v0.1)
        c.execute("SELECT COUNT(*) FROM actors")
        if c.fetchone()[0] == 0:
            c.executemany(
                "INSERT INTO actors (actor_id, actor_type, display_name, contact, is_active) VALUES (?,?,?,?,?)",
                [
                    ("user", "human", "わたし", "", 1),
                    ("claude-code", "ai", "クロードコード", None, 1),
                    ("system-morning-dispatcher", "system", "朝のディスパッチャー", None, 1),
                    ("system-deadline-checker", "system", "期限チェッカー", None, 1),
                    ("system-auto-mover", "system", "自動移動", None, 1),
                    ("system-weekly-summary", "system", "週次サマリー", None, 1),
                ],
            )

        conn.commit()


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def row_to_dict(row):
    return {k: row[k] for k in row.keys()} if row else None
