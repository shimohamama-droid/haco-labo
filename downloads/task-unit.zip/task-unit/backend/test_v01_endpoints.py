"""v0.1 指示書APIの動作確認スクリプト (Phase 0)。
TestClient で main.py のエンドポイントを直接叩いて結果を表示する。
"""
import json
import sys
from fastapi.testclient import TestClient

from main import app

client = TestClient(app)


def show(label, resp):
    print(f"\n--- {label} ---")
    print(f"HTTP {resp.status_code}")
    try:
        data = resp.json()
        print(json.dumps(data, ensure_ascii=False, indent=2)[:2000])
    except Exception:
        print(resp.text[:500])
    return resp


def assert_status(resp, expected, label):
    if resp.status_code != expected:
        print(f"\n!!! FAIL: {label} expected {expected} got {resp.status_code}")
        sys.exit(1)


# 1. Actors list
r = show("1. GET /api/actors", client.get("/api/actors"))
assert_status(r, 200, "list_actors")
assert len(r.json()) >= 6, "expected at least 6 actors"

# 2. Boards list (find 汎用)
r = show("2. GET /api/boards", client.get("/api/boards"))
assert_status(r, 200, "list_boards")
boards = r.json()
hanyou = next((b for b in boards if b["name"] == "汎用"), None)
assert hanyou, "汎用 board not found"
HANYOU_ID = hanyou["id"]

# 3. 指示書作成: ちか → クロードコード
payload = {
    "board_id": HANYOU_ID,
    "subject": "テスト: Sシリーズ売上集計",
    "body": "先月分のSシリーズ各SKUの売上を集計してCSV出力してほしい",
    "from_actor": {
        "actor_type": "human",
        "actor_id": "chika-takagi",
        "display_name": "ちかちゃん",
    },
    "to_actor": {
        "actor_type": "ai",
        "actor_id": "claude-code",
        "display_name": "クロードコード",
    },
    "deadline": "2026-05-25T08:00:00Z",
    "urgency": "medium",
    "pos_x": 100,
    "pos_y": 100,
}
r = show("3. POST /api/instructions (create instruction)", client.post("/api/instructions", json=payload))
assert_status(r, 200, "create_instruction")
card = r.json()
CARD_ID = card["id"]
assert card["state"] == "waiting", "initial state should be waiting"
assert card["type"] == "instruction"
assert card["uuid"], "uuid should be auto-generated"

# 4. Single card fetch
r = show(f"4. GET /api/cards/{CARD_ID}", client.get(f"/api/cards/{CARD_ID}"))
assert_status(r, 200, "get_card")

# 5. waiting → in_progress
r = show(
    f"5. POST /api/cards/{CARD_ID}/transition (waiting -> in_progress)",
    client.post(
        f"/api/cards/{CARD_ID}/transition",
        json={
            "to_state": "in_progress",
            "actor": {"actor_type": "ai", "actor_id": "claude-code"},
            "details": {"trigger": "morning_dispatch"},
        },
    ),
)
assert_status(r, 200, "transition_to_in_progress")
assert r.json()["state"] == "in_progress"

# 6. in_progress → completed (handoff_note 必須)
r = show(
    f"6. POST /api/cards/{CARD_ID}/transition (in_progress -> completed) with handoff",
    client.post(
        f"/api/cards/{CARD_ID}/transition",
        json={
            "to_state": "completed",
            "actor": {"actor_type": "ai", "actor_id": "claude-code"},
            "handoff_note": {
                "what": "先月分23SKUを集計",
                "result": "売上¥1,234,567(前月比+5%)",
                "next": "3SKUが在庫薄、要発注",
                "evidence": "data/rakuten_orders.csv",
                "held_for_judgment": None,
            },
            "details": {"duration_seconds": 960},
        },
    ),
)
assert_status(r, 200, "transition_to_completed")
completed = r.json()
assert completed["state"] == "completed"
assert completed["is_editable"] == 0, "completed card should be locked"
assert completed["handoff_what"] == "先月分23SKUを集計"

# 7. completed → 他の状態 (失敗するはず)
r = show(
    f"7. POST /api/cards/{CARD_ID}/transition (completed -> waiting) SHOULD FAIL",
    client.post(
        f"/api/cards/{CARD_ID}/transition",
        json={
            "to_state": "waiting",
            "actor": {"actor_type": "human", "actor_id": "chika-takagi"},
        },
    ),
)
assert_status(r, 400, "transition_from_terminal_should_fail")

# 8. 完了済みカードの本文編集試行 (失敗するはず)
r = show(
    f"8. PATCH /api/cards/{CARD_ID} body edit SHOULD FAIL (locked)",
    client.patch(f"/api/cards/{CARD_ID}", json={"body": "編集試行"}),
)
assert_status(r, 423, "edit_locked_body_should_fail")

# 9. 位置だけは編集できる(ロック中でも)
r = show(
    f"9. PATCH /api/cards/{CARD_ID} pos_x change (allowed even when locked)",
    client.patch(f"/api/cards/{CARD_ID}", json={"pos_x": 500}),
)
assert_status(r, 200, "edit_position_should_succeed")

# 10. 履歴取得
r = show(f"10. GET /api/cards/{CARD_ID}/history", client.get(f"/api/cards/{CARD_ID}/history"))
assert_status(r, 200, "card_history")
hist = r.json()
assert len(hist) >= 3, f"expected >=3 history entries, got {len(hist)}"
actions = [h["action"] for h in hist]
assert "created" in actions
assert "state_changed" in actions

# 11. by-actor 検索 (claude-code 宛のカードを取得)
r = show(
    "11. GET /api/cards/by-actor/claude-code?role=to",
    client.get("/api/cards/by-actor/claude-code", params={"role": "to"}),
)
assert_status(r, 200, "cards_by_actor")
assert any(c["id"] == CARD_ID for c in r.json())

# 12. 本日のミッション (chika-takagi 視点)
r = show(
    "12. GET /api/today-missions/chika-takagi",
    client.get("/api/today-missions/chika-takagi"),
)
assert_status(r, 200, "today_missions")
mission = r.json()
print(f"\ncounts: {mission['counts']}")

# 13. 添付追加
r = show(
    f"13. POST /api/cards/{CARD_ID}/attachments (add file)",
    client.post(
        f"/api/cards/{CARD_ID}/attachments",
        json={"attach_type": "file", "value": "data/rakuten_orders.csv", "label": "元データ"},
    ),
)
assert_status(r, 200, "add_attachment")
ATTACH_ID = r.json()["id"]

# 14. 添付一覧
r = show(
    f"14. GET /api/cards/{CARD_ID}/attachments",
    client.get(f"/api/cards/{CARD_ID}/attachments"),
)
assert_status(r, 200, "list_attachments")
assert len(r.json()) == 1

# 15. 不正な actor で指示書作成 (失敗するはず)
bad = dict(payload)
bad["to_actor"] = {"actor_type": "ai", "actor_id": "non-existent-bot"}
r = show(
    "15. POST /api/instructions with invalid actor SHOULD FAIL",
    client.post("/api/instructions", json=bad),
)
assert_status(r, 400, "invalid_actor_should_fail")

# 16. decision_required without held_for_judgment (失敗するはず)
# 新規instructionを作って試す
r2 = client.post("/api/instructions", json=payload).json()
new_card_id = r2["id"]
client.post(
    f"/api/cards/{new_card_id}/transition",
    json={"to_state": "in_progress", "actor": {"actor_type": "ai", "actor_id": "claude-code"}},
)
r = show(
    f"16. POST /api/cards/{new_card_id}/transition (in_progress -> decision_required) without held_for_judgment SHOULD FAIL",
    client.post(
        f"/api/cards/{new_card_id}/transition",
        json={
            "to_state": "decision_required",
            "actor": {"actor_type": "ai", "actor_id": "claude-code"},
            "handoff_note": {
                "what": "確認した",
                "result": "判断保留",
                "next": "人間判断",
                "evidence": "なし",
                # held_for_judgment 未指定
            },
        },
    ),
)
assert_status(r, 400, "decision_required_needs_held_for_judgment")

# 17. クリーンアップ(後始末): テスト用カードを削除
client.delete(f"/api/cards/{new_card_id}")
# CARD_IDは completed 状態なので残しておく(履歴の確認用)

print("\n" + "=" * 60)
print("✅ All v0.1 endpoint tests passed!")
print("=" * 60)
print(f"\n保持テストデータ: card_id={CARD_ID} (completed状態、履歴+添付付き)")
print("削除するには: sqlite3 task_unit.db \"DELETE FROM cards WHERE id={CARD_ID}\"")
