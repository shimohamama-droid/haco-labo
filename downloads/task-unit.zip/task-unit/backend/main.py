import os
import json
import uuid as _uuid
from datetime import date, datetime, timedelta
from typing import Optional, Any

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from db import get_conn, init_db, row_to_dict

load_dotenv()

app = FastAPI(title="Task-Unit API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _startup():
    init_db()


# ---------- Schemas ----------
class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    category: Optional[str] = None
    type_tag: Optional[str] = None
    estimated_minutes: Optional[int] = None
    scheduled_date: Optional[str] = None  # ISO date


class TaskPatch(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    type_tag: Optional[str] = None
    estimated_minutes: Optional[int] = None
    actual_minutes: Optional[int] = None
    progress: Optional[int] = None
    status: Optional[str] = None
    scheduled_date: Optional[str] = None


class ReviewCreate(BaseModel):
    review_date: str
    total_minutes: int = 0
    completed_count: int = 0
    notes: Optional[str] = None


# ---------- Helpers ----------
def _today_iso() -> str:
    return date.today().isoformat()


# ---------- Tasks ----------
@app.get("/api/tasks")
def list_tasks(view: str = "all"):
    """view: today | overdue | upcoming | all"""
    today = _today_iso()
    where = ""
    params: tuple = ()
    if view == "today":
        where = "WHERE scheduled_date = ? AND status != 'done'"
        params = (today,)
    elif view == "overdue":
        where = "WHERE scheduled_date < ? AND status NOT IN ('done','abandoned')"
        params = (today,)
    elif view == "upcoming":
        where = "WHERE scheduled_date > ? AND status != 'done'"
        params = (today,)
    elif view == "done":
        where = "WHERE status = 'done'"
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            f"SELECT * FROM tasks {where} ORDER BY scheduled_date ASC, id DESC",
            params,
        )
        return [row_to_dict(r) for r in c.fetchall()]


@app.get("/api/tasks/summary")
def task_summary():
    today = _today_iso()
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            "SELECT COUNT(*) FROM tasks WHERE scheduled_date = ? AND status != 'done'",
            (today,),
        )
        today_open = c.fetchone()[0]
        c.execute(
            "SELECT COUNT(*) FROM tasks WHERE scheduled_date = ? AND status = 'done'",
            (today,),
        )
        today_done = c.fetchone()[0]
        c.execute(
            "SELECT COALESCE(SUM(actual_minutes),0) FROM tasks WHERE date(completed_at)=?",
            (today,),
        )
        today_minutes = c.fetchone()[0]
        c.execute(
            "SELECT COALESCE(SUM(estimated_minutes),0) FROM tasks WHERE scheduled_date = ?",
            (today,),
        )
        today_est = c.fetchone()[0]
        c.execute(
            "SELECT COUNT(*) FROM tasks WHERE scheduled_date < ? AND status NOT IN ('done','abandoned')",
            (today,),
        )
        overdue = c.fetchone()[0]
    return {
        "today_open": today_open,
        "today_done": today_done,
        "today_total": today_open + today_done,
        "today_minutes": today_minutes,
        "today_estimated_minutes": today_est,
        "overdue": overdue,
    }


@app.post("/api/tasks")
def create_task(payload: TaskCreate):
    sched = payload.scheduled_date or _today_iso()
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            """INSERT INTO tasks (title, description, category, type_tag, estimated_minutes, scheduled_date)
               VALUES (?,?,?,?,?,?)""",
            (
                payload.title,
                payload.description,
                payload.category,
                payload.type_tag,
                payload.estimated_minutes,
                sched,
            ),
        )
        conn.commit()
        new_id = c.lastrowid
        c.execute("SELECT * FROM tasks WHERE id=?", (new_id,))
        return row_to_dict(c.fetchone())


@app.patch("/api/tasks/{task_id}")
def patch_task(task_id: int, payload: TaskPatch):
    fields = payload.model_dump(exclude_unset=True)
    if not fields:
        raise HTTPException(400, "no fields")
    # auto-set completed_at when status flips to done
    if fields.get("status") == "done":
        fields["completed_at"] = datetime.now().isoformat(timespec="seconds")
        if "progress" not in fields:
            fields["progress"] = 100
    sets = ", ".join(f"{k}=?" for k in fields)
    vals = list(fields.values()) + [task_id]
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(f"UPDATE tasks SET {sets} WHERE id=?", vals)
        conn.commit()
        c.execute("SELECT * FROM tasks WHERE id=?", (task_id,))
        row = c.fetchone()
        if not row:
            raise HTTPException(404, "task not found")
        return row_to_dict(row)


@app.delete("/api/tasks/{task_id}")
def delete_task(task_id: int):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("DELETE FROM tasks WHERE id=?", (task_id,))
        conn.commit()
    return {"ok": True}


@app.post("/api/tasks/{task_id}/move-to-today")
def move_to_today(task_id: int):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            "UPDATE tasks SET scheduled_date=? WHERE id=?",
            (_today_iso(), task_id),
        )
        conn.commit()
        c.execute("SELECT * FROM tasks WHERE id=?", (task_id,))
        return row_to_dict(c.fetchone())


# ---------- Reviews ----------
@app.get("/api/reviews/yesterday")
def yesterday_review_data():
    """Return data needed to render yesterday's review modal."""
    y = (date.today() - timedelta(days=1)).isoformat()
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            "SELECT * FROM tasks WHERE date(completed_at)=? ORDER BY completed_at",
            (y,),
        )
        completed = [row_to_dict(r) for r in c.fetchall()]
        c.execute("SELECT * FROM reviews WHERE review_date=?", (y,))
        existing = row_to_dict(c.fetchone())
    total = sum((t.get("actual_minutes") or 0) for t in completed)
    return {
        "review_date": y,
        "completed_tasks": completed,
        "total_minutes": total,
        "existing_review": existing,
    }


@app.post("/api/reviews")
def save_review(payload: ReviewCreate):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            """INSERT INTO reviews (review_date, total_minutes, completed_count, notes)
               VALUES (?,?,?,?)""",
            (
                payload.review_date,
                payload.total_minutes,
                payload.completed_count,
                payload.notes,
            ),
        )
        conn.commit()
        c.execute("SELECT * FROM reviews WHERE id=?", (c.lastrowid,))
        return row_to_dict(c.fetchone())


# ---------- Notes ----------
class NoteCreate(BaseModel):
    title: Optional[str] = None
    body: str
    tags: Optional[str] = None
    category: Optional[str] = None


class NotePatch(BaseModel):
    title: Optional[str] = None
    body: Optional[str] = None
    tags: Optional[str] = None
    category: Optional[str] = None


@app.get("/api/notes")
def list_notes():
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM notes ORDER BY updated_at DESC, id DESC")
        return [row_to_dict(r) for r in c.fetchall()]


@app.post("/api/notes")
def create_note(payload: NoteCreate):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            "INSERT INTO notes (title, body, tags, category) VALUES (?,?,?,?)",
            (payload.title, payload.body, payload.tags, payload.category),
        )
        conn.commit()
        c.execute("SELECT * FROM notes WHERE id=?", (c.lastrowid,))
        return row_to_dict(c.fetchone())


@app.patch("/api/notes/{note_id}")
def patch_note(note_id: int, payload: NotePatch):
    fields = payload.model_dump(exclude_unset=True)
    if not fields:
        raise HTTPException(400, "no fields")
    fields["updated_at"] = datetime.now().isoformat(timespec="seconds")
    sets = ", ".join(f"{k}=?" for k in fields)
    vals = list(fields.values()) + [note_id]
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(f"UPDATE notes SET {sets} WHERE id=?", vals)
        conn.commit()
        c.execute("SELECT * FROM notes WHERE id=?", (note_id,))
        return row_to_dict(c.fetchone())


@app.delete("/api/notes/{note_id}")
def delete_note(note_id: int):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("DELETE FROM notes WHERE id=?", (note_id,))
        conn.commit()
    return {"ok": True}


@app.post("/api/tasks/{task_id}/convert-to-note")
def task_to_note(task_id: int):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM tasks WHERE id=?", (task_id,))
        t = c.fetchone()
        if not t:
            raise HTTPException(404, "task not found")
        c.execute(
            """INSERT INTO notes (title, body, category, linked_task_id)
               VALUES (?,?,?,?)""",
            (t["title"], t["description"], t["category"], task_id),
        )
        conn.commit()
        c.execute("SELECT * FROM notes WHERE id=?", (c.lastrowid,))
        return row_to_dict(c.fetchone())


@app.post("/api/tasks/move-all-to-today")
def move_all_overdue():
    today = _today_iso()
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            "UPDATE tasks SET scheduled_date=? WHERE scheduled_date<? AND status NOT IN ('done','abandoned')",
            (today, today),
        )
        conn.commit()
        return {"moved": c.rowcount}


@app.post("/api/notes/{note_id}/convert-to-task")
def convert_note_to_task(note_id: int):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM notes WHERE id=?", (note_id,))
        n = c.fetchone()
        if not n:
            raise HTTPException(404, "note not found")
        c.execute(
            """INSERT INTO tasks (title, description, category, scheduled_date)
               VALUES (?,?,?,?)""",
            (n["title"] or (n["body"] or "")[:40], n["body"], n["category"], _today_iso()),
        )
        task_id = c.lastrowid
        c.execute(
            "UPDATE notes SET linked_task_id=? WHERE id=?", (task_id, note_id)
        )
        conn.commit()
        c.execute("SELECT * FROM tasks WHERE id=?", (task_id,))
        return row_to_dict(c.fetchone())


# ---------- Boards & Cards ----------
class CardCreate(BaseModel):
    board_id: int
    card_type: str = "idea"  # "todo" | "idea"
    title: Optional[str] = None
    body: Optional[str] = None
    color: str = "yellow"
    pos_x: int = 40
    pos_y: int = 40
    width: int = 200
    height: int = 120
    trigger_condition: Optional[str] = None


class CardPatch(BaseModel):
    title: Optional[str] = None
    body: Optional[str] = None
    color: Optional[str] = None
    pos_x: Optional[int] = None
    pos_y: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None
    is_completed: Optional[int] = None
    trigger_condition: Optional[str] = None


@app.get("/api/boards")
def list_boards():
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM boards ORDER BY display_order, id")
        return [row_to_dict(r) for r in c.fetchall()]


@app.get("/api/boards/{board_id}/cards")
def list_cards(board_id: int):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            "SELECT * FROM cards WHERE board_id=? ORDER BY id", (board_id,)
        )
        return [row_to_dict(r) for r in c.fetchall()]


@app.post("/api/cards")
def create_card(payload: CardCreate):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            """INSERT INTO cards (board_id, card_type, title, body, color,
                                  pos_x, pos_y, width, height, trigger_condition)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (
                payload.board_id,
                payload.card_type,
                payload.title,
                payload.body,
                payload.color,
                payload.pos_x,
                payload.pos_y,
                payload.width,
                payload.height,
                payload.trigger_condition,
            ),
        )
        conn.commit()
        c.execute("SELECT * FROM cards WHERE id=?", (c.lastrowid,))
        return row_to_dict(c.fetchone())


@app.patch("/api/cards/{card_id}")
def patch_card(card_id: int, payload: CardPatch):
    fields = payload.model_dump(exclude_unset=True)
    if not fields:
        raise HTTPException(400, "no fields")
    with get_conn() as conn:
        c = conn.cursor()
        # v0.1: 編集ロックチェック(位置・色などはロック中も許可、本文系のみブロック)
        c.execute("SELECT is_editable, edit_locked_reason, type FROM cards WHERE id=?", (card_id,))
        row = c.fetchone()
        if not row:
            raise HTTPException(404, "card not found")
        is_editable = row["is_editable"] if "is_editable" in row.keys() else 1
        if is_editable == 0:
            # 位置/サイズ/色だけは編集可、本文系はブロック
            blocked_keys = {"title", "body", "trigger_condition", "is_completed"}
            attempted_blocked = set(fields.keys()) & blocked_keys
            if attempted_blocked:
                raise HTTPException(
                    423,
                    f"card is locked (reason: {row['edit_locked_reason']}). "
                    f"cannot edit: {sorted(attempted_blocked)}",
                )
        fields["updated_at"] = datetime.now().isoformat(timespec="seconds")
        sets = ", ".join(f"{k}=?" for k in fields)
        vals = list(fields.values()) + [card_id]
        c.execute(f"UPDATE cards SET {sets} WHERE id=?", vals)
        conn.commit()
        c.execute("SELECT * FROM cards WHERE id=?", (card_id,))
        return row_to_dict(c.fetchone())


@app.delete("/api/cards/{card_id}")
def delete_card(card_id: int):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("DELETE FROM cards WHERE id=?", (card_id,))
        conn.commit()
    return {"ok": True}


@app.post("/api/cards/{card_id}/convert-to-task")
def card_to_task(card_id: int):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM cards WHERE id=?", (card_id,))
        card = c.fetchone()
        if not card:
            raise HTTPException(404, "card not found")
        c.execute(
            """INSERT INTO tasks (title, description, scheduled_date, source_card_id)
               VALUES (?,?,?,?)""",
            (
                card["title"] or "(無題)",
                card["body"],
                _today_iso(),
                card_id,
            ),
        )
        task_id = c.lastrowid
        c.execute(
            "UPDATE cards SET converted_to_task_id=? WHERE id=?",
            (task_id, card_id),
        )
        conn.commit()
        c.execute("SELECT * FROM tasks WHERE id=?", (task_id,))
        return row_to_dict(c.fetchone())


# ---------- AI 所要時間予測 ----------
class PredictRequest(BaseModel):
    title: str
    category: Optional[str] = None


@app.post("/api/predict-minutes")
def predict_minutes(payload: PredictRequest):
    """類似過去タスクの平均で予測。Anthropic API キーがあれば Haiku に投げ直す。"""
    with get_conn() as conn:
        c = conn.cursor()
        # crude similarity: same category + LIKE on first 2 chars
        like = f"%{payload.title[:4]}%" if payload.title else "%"
        c.execute(
            """SELECT title, actual_minutes FROM tasks
               WHERE actual_minutes IS NOT NULL AND status='done'
                 AND (category=? OR title LIKE ?)
               ORDER BY id DESC LIMIT 8""",
            (payload.category or "", like),
        )
        similar = [row_to_dict(r) for r in c.fetchall()]

    if not similar:
        return {"minutes": 60, "confidence": "low", "reasoning": "過去データなし。デフォルト60分"}

    avg = sum((t["actual_minutes"] or 0) for t in similar) / len(similar)
    base = int(round(avg))

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return {
            "minutes": base,
            "confidence": "medium",
            "reasoning": f"過去{len(similar)}件の平均",
            "similar": similar,
        }

    try:
        from anthropic import Anthropic

        client = Anthropic(api_key=api_key)
        prompt = (
            "あなたはユーザーのタスク所要時間を予測するAIです。\n"
            f"【新規タスク】タイトル: {payload.title}\n"
            f"カテゴリ: {payload.category or '未指定'}\n"
            "【過去の類似タスク（タイトル / 実所要分）】\n"
            + "\n".join(f"- {t['title']} / {t['actual_minutes']}分" for t in similar)
            + "\n出力はJSONのみ。{\"minutes\": int, \"confidence\": \"high|medium|low\", \"reasoning\": \"...\"}"
        )
        msg = client.messages.create(
            model="claude-haiku-4-5",
            max_tokens=300,
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(b.text for b in msg.content if hasattr(b, "text"))
        import json, re

        m = re.search(r"\{.*\}", text, re.S)
        data = json.loads(m.group(0)) if m else {}
        data.setdefault("minutes", base)
        data.setdefault("confidence", "medium")
        data["similar"] = similar
        return data
    except Exception as e:
        return {
            "minutes": base,
            "confidence": "medium",
            "reasoning": f"AI呼出失敗フォールバック ({e.__class__.__name__})。過去{len(similar)}件平均",
            "similar": similar,
        }


# ---------- v0.1: 指示書カード (Instruction Cards) ----------

# State transition rules
ALLOWED_TRANSITIONS: dict[str, set[str]] = {
    "waiting": {"in_progress", "overdue"},
    "in_progress": {"completed", "decision_required", "overdue"},
    "completed": set(),
    "decision_required": {"waiting", "completed"},
    "overdue": {"in_progress", "completed", "decision_required", "abandoned"},
    "abandoned": set(),
}

TERMINAL_STATES = {"completed", "abandoned"}


class ActorRef(BaseModel):
    actor_type: str  # human / ai / system
    actor_id: str
    display_name: Optional[str] = None


class HandoffNote(BaseModel):
    what: str
    result: str
    next: str
    evidence: str
    held_for_judgment: Optional[str] = None


class InstructionCardCreate(BaseModel):
    board_id: int
    subject: str
    body: str
    from_actor: ActorRef
    to_actor: ActorRef
    deadline: Optional[str] = None  # ISO 8601
    urgency: str = "medium"  # low / medium / high
    color: str = "yellow"
    pos_x: int = 40
    pos_y: int = 40
    width: int = 200
    height: int = 120


class StateTransition(BaseModel):
    to_state: str
    actor: ActorRef
    handoff_note: Optional[HandoffNote] = None
    details: Optional[dict] = None


class AttachmentCreate(BaseModel):
    attach_type: str  # file / url
    value: str
    label: Optional[str] = None


class AssignActor(BaseModel):
    """ドラッグ&ドロップでカードをAIに割り当てるための簡易API。"""
    to_actor_id: str
    from_actor_id: Optional[str] = None  # 未指定なら既存の from を維持、なければ user


def _add_history(
    c,
    card_id: int,
    actor: ActorRef,
    action: str,
    from_state: Optional[str] = None,
    to_state: Optional[str] = None,
    details: Optional[dict] = None,
):
    """card_history テーブルに履歴を追記。"""
    c.execute(
        """INSERT INTO card_history (card_id, actor_type, actor_id, action, from_state, to_state, details)
           VALUES (?,?,?,?,?,?,?)""",
        (
            card_id,
            actor.actor_type,
            actor.actor_id,
            action,
            from_state,
            to_state,
            json.dumps(details or {}, ensure_ascii=False),
        ),
    )


def _verify_actor_exists(c, actor_id: str):
    c.execute("SELECT actor_id FROM actors WHERE actor_id=? AND is_active=1", (actor_id,))
    if not c.fetchone():
        raise HTTPException(400, f"actor not found or inactive: {actor_id}")


@app.post("/api/instructions")
def create_instruction(payload: InstructionCardCreate):
    """指示書カードを新規作成。card_type='instruction', state='waiting' 固定。"""
    new_uuid = str(_uuid.uuid4())
    with get_conn() as conn:
        c = conn.cursor()
        _verify_actor_exists(c, payload.from_actor.actor_id)
        _verify_actor_exists(c, payload.to_actor.actor_id)
        # ボードの存在確認
        c.execute("SELECT id FROM boards WHERE id=?", (payload.board_id,))
        if not c.fetchone():
            raise HTTPException(400, f"board not found: {payload.board_id}")
        c.execute(
            """INSERT INTO cards (
                board_id, card_type, type, schema_version, uuid,
                title, subject, body, color, pos_x, pos_y, width, height,
                from_actor_type, from_actor_id, from_display_name,
                to_actor_type, to_actor_id, to_display_name,
                deadline, urgency, state, is_editable
            ) VALUES (?,?,?,?,?, ?,?,?,?,?,?,?,?, ?,?,?, ?,?,?, ?,?,?,?)""",
            (
                payload.board_id, "instruction", "instruction", 1, new_uuid,
                payload.subject, payload.subject, payload.body, payload.color,
                payload.pos_x, payload.pos_y, payload.width, payload.height,
                payload.from_actor.actor_type, payload.from_actor.actor_id, payload.from_actor.display_name,
                payload.to_actor.actor_type, payload.to_actor.actor_id, payload.to_actor.display_name,
                payload.deadline, payload.urgency, "waiting", 1,
            ),
        )
        new_id = c.lastrowid
        _add_history(
            c, new_id, payload.from_actor, "created",
            from_state=None, to_state="waiting",
            details={"subject": payload.subject, "urgency": payload.urgency},
        )
        conn.commit()
        c.execute("SELECT * FROM cards WHERE id=?", (new_id,))
        return row_to_dict(c.fetchone())


@app.post("/api/cards/{card_id}/transition")
def transition_card(card_id: int, payload: StateTransition):
    """状態遷移を実行。card_history に自動記録、必要時に編集ロック。"""
    with get_conn() as conn:
        c = conn.cursor()
        _verify_actor_exists(c, payload.actor.actor_id)
        c.execute("SELECT * FROM cards WHERE id=?", (card_id,))
        card = c.fetchone()
        if not card:
            raise HTTPException(404, "card not found")
        current_state = card["state"] or "waiting"
        new_state = payload.to_state

        allowed = ALLOWED_TRANSITIONS.get(current_state, set())
        if new_state not in allowed:
            raise HTTPException(
                400,
                f"transition not allowed: {current_state} -> {new_state}. "
                f"allowed: {sorted(allowed)}",
            )

        # 必須バリデーション
        if new_state == "completed" and not payload.handoff_note:
            raise HTTPException(400, "handoff_note is required when transitioning to 'completed'")
        if new_state == "decision_required":
            if not payload.handoff_note or not payload.handoff_note.held_for_judgment:
                raise HTTPException(
                    400,
                    "handoff_note.held_for_judgment is required when transitioning to 'decision_required'",
                )

        updates = {"state": new_state, "updated_at": datetime.now().isoformat(timespec="seconds")}
        if new_state in TERMINAL_STATES:
            updates["is_editable"] = 0
            updates["edit_locked_reason"] = f"state_{new_state}"
        if payload.handoff_note:
            hn = payload.handoff_note
            updates.update({
                "handoff_what": hn.what,
                "handoff_result": hn.result,
                "handoff_next": hn.next,
                "handoff_evidence": hn.evidence,
                "handoff_held_for_judgment": hn.held_for_judgment,
            })

        sets = ", ".join(f"{k}=?" for k in updates)
        vals = list(updates.values()) + [card_id]
        c.execute(f"UPDATE cards SET {sets} WHERE id=?", vals)

        _add_history(
            c, card_id, payload.actor, "state_changed",
            from_state=current_state, to_state=new_state,
            details=payload.details,
        )
        conn.commit()
        c.execute("SELECT * FROM cards WHERE id=?", (card_id,))
        return row_to_dict(c.fetchone())


@app.post("/api/cards/{card_id}/assign")
def assign_card(card_id: int, payload: AssignActor):
    """既存カードを指示書に変換(or 宛先更新)。ドラッグ&ドロップ用。

    - type が 'instruction' でなければ 'instruction' に変換
    - state が未設定なら 'waiting'
    - from_actor 未指定なら既存の from を維持、それも無ければ user
    - history に 'assigned' エントリ追記
    """
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM cards WHERE id=?", (card_id,))
        card = c.fetchone()
        if not card:
            raise HTTPException(404, "card not found")

        # 宛先 actor 確認
        c.execute(
            "SELECT actor_type, actor_id, display_name FROM actors WHERE actor_id=? AND is_active=1",
            (payload.to_actor_id,),
        )
        to_row = c.fetchone()
        if not to_row:
            raise HTTPException(400, f"to_actor not found: {payload.to_actor_id}")

        # 差出人 actor の決定 (優先順位: payload > 既存 > user)
        from_actor_id = (
            payload.from_actor_id
            or (card["from_actor_id"] if "from_actor_id" in card.keys() else None)
            or "user"
        )
        c.execute(
            "SELECT actor_type, actor_id, display_name FROM actors WHERE actor_id=? AND is_active=1",
            (from_actor_id,),
        )
        from_row = c.fetchone()
        if not from_row:
            raise HTTPException(400, f"from_actor not found: {from_actor_id}")

        # uuid 生成(まだなら)
        new_uuid = card["uuid"] if (card["uuid"] if "uuid" in card.keys() else None) else str(_uuid.uuid4())

        updates = {
            "type": "instruction",
            "from_actor_type": from_row["actor_type"],
            "from_actor_id": from_row["actor_id"],
            "from_display_name": from_row["display_name"],
            "to_actor_type": to_row["actor_type"],
            "to_actor_id": to_row["actor_id"],
            "to_display_name": to_row["display_name"],
            "state": card["state"] if (card["state"] if "state" in card.keys() else None) else "waiting",
            "uuid": new_uuid,
            "updated_at": datetime.now().isoformat(timespec="seconds"),
        }
        # subject が無ければ title から
        if not (card["subject"] if "subject" in card.keys() else None):
            updates["subject"] = card["title"] or "(無題)"

        sets = ", ".join(f"{k}=?" for k in updates)
        vals = list(updates.values()) + [card_id]
        c.execute(f"UPDATE cards SET {sets} WHERE id=?", vals)

        # history 追記
        actor_ref = ActorRef(
            actor_type=from_row["actor_type"],
            actor_id=from_row["actor_id"],
            display_name=from_row["display_name"],
        )
        _add_history(
            c, card_id, actor_ref, "assigned",
            from_state=None, to_state=updates["state"],
            details={
                "to_actor_id": to_row["actor_id"],
                "to_display_name": to_row["display_name"],
                "trigger": "drag_and_drop",
            },
        )
        conn.commit()
        c.execute("SELECT * FROM cards WHERE id=?", (card_id,))
        return row_to_dict(c.fetchone())


@app.get("/api/cards/{card_id}")
def get_card(card_id: int):
    """単一カード取得(全v0.1フィールド込み)。"""
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM cards WHERE id=?", (card_id,))
        row = c.fetchone()
        if not row:
            raise HTTPException(404, "card not found")
        return row_to_dict(row)


@app.get("/api/cards/{card_id}/history")
def card_history(card_id: int):
    """カードの履歴を時系列で返す。"""
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            "SELECT * FROM card_history WHERE card_id=? ORDER BY timestamp ASC, id ASC",
            (card_id,),
        )
        rows = [row_to_dict(r) for r in c.fetchall()]
        for r in rows:
            if r.get("details"):
                try:
                    r["details"] = json.loads(r["details"])
                except Exception:
                    pass
        return rows


# ---------- Actor マスタ ----------
@app.get("/api/actors")
def list_actors(actor_type: Optional[str] = None, active_only: bool = True):
    """Actor マスタ取得(差出人/宛先ドロップダウン用)。"""
    with get_conn() as conn:
        c = conn.cursor()
        where_parts = []
        params: list = []
        if actor_type:
            where_parts.append("actor_type=?")
            params.append(actor_type)
        if active_only:
            where_parts.append("is_active=1")
        where = ("WHERE " + " AND ".join(where_parts)) if where_parts else ""
        c.execute(
            f"SELECT * FROM actors {where} ORDER BY actor_type, display_name",
            params,
        )
        return [row_to_dict(r) for r in c.fetchall()]


# ---------- カード検索 ----------
@app.get("/api/cards/by-actor/{actor_id}")
def cards_by_actor(actor_id: str, role: str = "to", state: Optional[str] = None):
    """role=to: actor_id宛のカード, role=from: actor_id発のカード。MCP用エンドポイント。"""
    if role not in ("to", "from"):
        raise HTTPException(400, "role must be 'to' or 'from'")
    field = f"{role}_actor_id"
    with get_conn() as conn:
        c = conn.cursor()
        if state:
            c.execute(
                f"SELECT * FROM cards WHERE {field}=? AND state=? "
                "ORDER BY (deadline IS NULL), deadline ASC, id ASC",
                (actor_id, state),
            )
        else:
            c.execute(
                f"SELECT * FROM cards WHERE {field}=? "
                "ORDER BY (deadline IS NULL), deadline ASC, id ASC",
                (actor_id,),
            )
        return [row_to_dict(r) for r in c.fetchall()]


# ---------- 添付 ----------
@app.get("/api/cards/{card_id}/attachments")
def list_attachments(card_id: int):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            "SELECT * FROM attachments WHERE card_id=? ORDER BY id",
            (card_id,),
        )
        return [row_to_dict(r) for r in c.fetchall()]


@app.post("/api/cards/{card_id}/attachments")
def add_attachment(card_id: int, payload: AttachmentCreate):
    if payload.attach_type not in ("file", "url"):
        raise HTTPException(400, "attach_type must be 'file' or 'url'")
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("SELECT id FROM cards WHERE id=?", (card_id,))
        if not c.fetchone():
            raise HTTPException(404, "card not found")
        c.execute(
            "INSERT INTO attachments (card_id, attach_type, value, label) VALUES (?,?,?,?)",
            (card_id, payload.attach_type, payload.value, payload.label),
        )
        conn.commit()
        c.execute("SELECT * FROM attachments WHERE id=?", (c.lastrowid,))
        return row_to_dict(c.fetchone())


@app.delete("/api/attachments/{attachment_id}")
def delete_attachment(attachment_id: int):
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("DELETE FROM attachments WHERE id=?", (attachment_id,))
        conn.commit()
    return {"ok": True}


# ---------- 本日のミッション(MVP) ----------
@app.get("/api/today-missions/{actor_id}")
def today_missions(actor_id: str):
    """ある actor の本日のミッション集約。
    - 夜中にAIが片付けた(completed)
    - 判断要請(decision_required)
    - 未着手(waiting で自分宛)
    - 進行中(in_progress)
    - 期限切れ警告(overdue)
    """
    with get_conn() as conn:
        c = conn.cursor()
        c.execute(
            """SELECT * FROM cards
               WHERE (to_actor_id=? OR from_actor_id=?) AND type='instruction'
               ORDER BY state, (deadline IS NULL), deadline ASC, id ASC""",
            (actor_id, actor_id),
        )
        all_cards = [row_to_dict(r) for r in c.fetchall()]
    completed = [x for x in all_cards if x.get("state") == "completed"]
    decision_required = [x for x in all_cards if x.get("state") == "decision_required"]
    waiting = [
        x for x in all_cards
        if x.get("state") == "waiting" and x.get("to_actor_id") == actor_id
    ]
    in_progress = [x for x in all_cards if x.get("state") == "in_progress"]
    overdue = [x for x in all_cards if x.get("state") == "overdue"]
    return {
        "actor_id": actor_id,
        "as_of": datetime.now().isoformat(timespec="seconds"),
        "completed": completed,
        "decision_required": decision_required,
        "waiting": waiting,
        "in_progress": in_progress,
        "overdue": overdue,
        "counts": {
            "completed": len(completed),
            "decision_required": len(decision_required),
            "waiting": len(waiting),
            "in_progress": len(in_progress),
            "overdue": len(overdue),
        },
    }


@app.get("/")
def root():
    return {"app": "Task-Unit", "status": "ok", "spec_version": "0.1"}
