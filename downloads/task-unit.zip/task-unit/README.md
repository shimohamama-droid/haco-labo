# TASK-UNIT（HACO LABO）

付箋ボード付きのタスク管理Webアプリです。ブラウザ（localhost）で動き、
データはすべて自分のPCのSQLiteに保存されます。

## 主な機能

- タスク管理: 今日 / 持ち越し / 今後 の3カラム、進捗％スライダー、実所要時間の記録
- ショートカット入力: `:カテゴリ` `#種別` `!分` `/tomorrow` `/2026-07-01`
- AI所要時間予測: 過去の類似タスクから所要時間を予測（Anthropic APIキーがあれば Claude が予測。なくても単純平均で動作）
- 自由配置付箋ボード: ダブルクリックでカード生成、ドラッグ移動、右クリックで色変更・タスク化
- 中断BOX: 「いつか再開する案件」をトリガー条件付きで寝かせておくボード
- 撤収スクリプト: 全データをExcel等にエクスポート（ベンダーロックインなし）

## 必要なもの

- Mac（macOS）+ Python 3.10以上 + Node.js 18以上

## 起動

```bash
cd task-unit
./start.sh
```

初回は自動セットアップ（venv作成 + npm install）が走ります（2〜3分）。

- アプリ画面: http://localhost:5173
- 停止: Ctrl+C

## AI予測を使いたい場合（任意）

`backend/.env` に Anthropic APIキーを設定:

```
ANTHROPIC_API_KEY=sk-ant-あなたのキー
```

## データの場所

`backend/task_unit.db`（SQLite）。バックアップはこのファイルをコピーするだけ。
全データのエクスポートは `backend/withdraw.py` を参照。

---
HACO LABO — 小さなアプリの玩具箱
